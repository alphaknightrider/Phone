package com.example

import android.app.Application
import com.example.database.KlashDatabase
import com.example.security.SecurityManager
import com.example.tools.ToolRegistry

class KlashApplication : Application() {
    lateinit var database: KlashDatabase
        private set

    lateinit var securityManager: SecurityManager
        private set

    lateinit var toolRegistry: ToolRegistry
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = KlashDatabase.getInstance(this)
        securityManager = SecurityManager(this)
        toolRegistry = ToolRegistry(this)
    }

    companion object {
        lateinit var instance: KlashApplication
            private set
    }
}
