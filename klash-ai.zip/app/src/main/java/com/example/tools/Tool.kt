package com.example.tools

import android.content.Context
import com.example.security.RiskLevel

data class ToolResult(
    val isSuccess: Boolean,
    val spokenSummary: String,
    val rawData: Map<String, Any?> = emptyMap()
)

interface Tool {
    val name: String
    val description: String
    val riskLevel: RiskLevel
    val requiredPermission: String?

    suspend fun execute(context: Context, arguments: Map<String, String>): ToolResult
}
