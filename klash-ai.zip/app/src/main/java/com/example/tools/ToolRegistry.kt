package com.example.tools

import android.content.Context
import com.example.KlashApplication
import com.example.database.ToolExecutionEntity
import com.example.security.RiskLevel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ToolRegistry(private val context: Context) {
    private val tools = mutableMapOf<String, Tool>()

    init {
        registerTool(RamTool())
        registerTool(StorageTool())
        registerTool(BatteryTool())
        registerTool(NetworkTool())
        registerTool(DeviceInfoTool())
        registerTool(FileTool())
        registerTool(AppTool())
        registerTool(WebSearchTool())

        val secMgr = (context.applicationContext as? KlashApplication)?.securityManager
            ?: com.example.security.SecurityManager(context)
        registerTool(PterodactylTool(secMgr))
        registerTool(DiscordTool(secMgr))
    }

    fun registerTool(tool: Tool) {
        tools[tool.name.lowercase()] = tool
    }

    fun getTool(name: String): Tool? {
        val key = name.lowercase().trim()
        return tools[key] ?: when (key) {
            "ram", "get_ram" -> tools["get_ram"]
            "storage", "get_storage" -> tools["get_storage"]
            "battery", "get_battery" -> tools["get_battery"]
            "network", "get_network" -> tools["get_network"]
            "device", "get_device_info" -> tools["get_device_info"]
            "server_status", "player_count", "server_restart", "server_stop" -> tools["pterodactyl"]
            "send_message", "send_announcement" -> tools["discord"]
            "search", "web_search" -> tools["web_search"]
            "files", "list_permitted_files", "create_file", "read_permitted_file" -> tools["permitted_files"]
            else -> null
        }
    }

    fun getAllTools(): List<Tool> = tools.values.toList()

    suspend fun executeTool(
        toolName: String,
        arguments: Map<String, String> = emptyMap(),
        callId: Long = 0,
        callerTier: String = "OWNER"
    ): ToolResult = withContext(Dispatchers.IO) {
        val tool = getTool(toolName)
        if (tool == null) {
            return@withContext ToolResult(false, "Tool '$toolName' is not registered.")
        }

        // Restrict sensitive/high-risk tools if caller is GUEST
        if (callerTier == "GUEST" && tool.riskLevel != RiskLevel.LOW) {
            return@withContext ToolResult(
                false,
                "Unauthorized: Guest callers are restricted from executing administrative tool '$toolName'."
            )
        }

        val result = try {
            tool.execute(context, arguments)
        } catch (e: Exception) {
            ToolResult(false, "Error executing tool ${tool.name}: ${e.message}")
        }

        // Log execution in Room Database
        try {
            val db = (context.applicationContext as? KlashApplication)?.database
            db?.toolExecutionDao()?.insertExecution(
                ToolExecutionEntity(
                    callId = callId,
                    toolName = tool.name,
                    argumentsJson = arguments.toString(),
                    resultSummary = result.spokenSummary,
                    status = if (result.isSuccess) "SUCCESS" else "FAILED",
                    timestamp = System.currentTimeMillis(),
                    riskLevel = tool.riskLevel.name
                )
            )
        } catch (_: Exception) {
            // Non-fatal logging failure
        }

        result
    }
}
