package com.example.tools

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import com.example.security.RiskLevel
import com.example.security.SecurityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit

class RamTool : Tool {
    override val name: String = "get_ram"
    override val description: String = "Returns total and available system RAM memory"
    override val riskLevel: RiskLevel = RiskLevel.LOW
    override val requiredPermission: String? = null

    override suspend fun execute(context: Context, arguments: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
        try {
            val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            actManager.getMemoryInfo(memInfo)
            val totalGb = memInfo.totalMem / (1024.0 * 1024.0 * 1024.0)
            val availGb = memInfo.availMem / (1024.0 * 1024.0 * 1024.0)
            val usedGb = totalGb - availGb
            val usedPct = ((usedGb / totalGb) * 100).toInt()

            val summary = String.format(
                Locale.US,
                "Your phone has approximately %.1f GB of RAM, with %.1f GB currently available.",
                totalGb,
                availGb
            )
            ToolResult(
                isSuccess = true,
                spokenSummary = summary,
                rawData = mapOf(
                    "total_gb" to totalGb,
                    "avail_gb" to availGb,
                    "used_percent" to usedPct,
                    "low_memory" to memInfo.lowMemory
                )
            )
        } catch (e: Exception) {
            ToolResult(false, "Could not determine RAM information: ${e.message}")
        }
    }
}

class StorageTool : Tool {
    override val name: String = "get_storage"
    override val description: String = "Returns total and available device internal storage space"
    override val riskLevel: RiskLevel = RiskLevel.LOW
    override val requiredPermission: String? = null

    override suspend fun execute(context: Context, arguments: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
        try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val totalBytes = stat.blockCountLong * stat.blockSizeLong
            val availBytes = stat.availableBlocksLong * stat.blockSizeLong
            val totalGb = totalBytes / (1024.0 * 1024.0 * 1024.0)
            val availGb = availBytes / (1024.0 * 1024.0 * 1024.0)

            val summary = String.format(
                Locale.US,
                "You currently have approximately %.1f GB of available storage out of %.1f GB total.",
                availGb,
                totalGb
            )
            ToolResult(
                isSuccess = true,
                spokenSummary = summary,
                rawData = mapOf(
                    "total_gb" to totalGb,
                    "avail_gb" to availGb,
                    "used_gb" to (totalGb - availGb)
                )
            )
        } catch (e: Exception) {
            ToolResult(false, "Could not read storage metrics: ${e.message}")
        }
    }
}

class BatteryTool : Tool {
    override val name: String = "get_battery"
    override val description: String = "Returns battery percentage and charging state"
    override val riskLevel: RiskLevel = RiskLevel.LOW
    override val requiredPermission: String? = null

    override suspend fun execute(context: Context, arguments: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
        try {
            val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { filter ->
                context.registerReceiver(null, filter)
            }
            val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale.toFloat()).toInt() else 0
            val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

            val summary = if (isCharging) {
                "Your battery is at $batteryPct percent and currently charging."
            } else {
                "Your battery is currently at $batteryPct percent."
            }

            ToolResult(
                isSuccess = true,
                spokenSummary = summary,
                rawData = mapOf(
                    "percent" to batteryPct,
                    "is_charging" to isCharging
                )
            )
        } catch (e: Exception) {
            ToolResult(false, "Could not read battery state: ${e.message}")
        }
    }
}

class NetworkTool : Tool {
    override val name: String = "get_network"
    override val description: String = "Returns current network status (Wi-Fi, Cellular, or Offline)"
    override val riskLevel: RiskLevel = RiskLevel.LOW
    override val requiredPermission: String? = null

    override suspend fun execute(context: Context, arguments: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val activeNetwork = cm.activeNetwork
            val capabilities = cm.getNetworkCapabilities(activeNetwork)
            val isConnected = capabilities != null &&
                    (capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))

            val type = when {
                capabilities == null -> "Offline"
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular data"
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                else -> "Active connection"
            }

            val summary = if (isConnected) {
                "The phone is online and connected via $type."
            } else {
                "The phone is currently offline with no active internet connection."
            }

            ToolResult(
                isSuccess = true,
                spokenSummary = summary,
                rawData = mapOf(
                    "is_connected" to isConnected,
                    "network_type" to type
                )
            )
        } catch (e: Exception) {
            ToolResult(false, "Network status unavailable: ${e.message}")
        }
    }
}

class DeviceInfoTool : Tool {
    override val name: String = "get_device_info"
    override val description: String = "Returns device model, manufacturer, and Android version"
    override val riskLevel: RiskLevel = RiskLevel.LOW
    override val requiredPermission: String? = null

    override suspend fun execute(context: Context, arguments: Map<String, String>): ToolResult {
        val manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = Build.MODEL
        val androidVer = Build.VERSION.RELEASE
        val summary = "This device is a $manufacturer $model running Android version $androidVer."

        return ToolResult(
            isSuccess = true,
            spokenSummary = summary,
            rawData = mapOf(
                "manufacturer" to manufacturer,
                "model" to model,
                "android_version" to androidVer,
                "sdk_int" to Build.VERSION.SDK_INT
            )
        )
    }
}

class FileTool : Tool {
    override val name: String = "permitted_files"
    override val description: String = "Manages files in the user-permitted application sandbox"
    override val riskLevel: RiskLevel = RiskLevel.MEDIUM
    override val requiredPermission: String? = null

    override suspend fun execute(context: Context, arguments: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
        val action = arguments["action"] ?: "list"
        val sandboxDir = File(context.filesDir, "klash_workspace").apply { if (!exists()) mkdirs() }

        when (action) {
            "list" -> {
                val files = sandboxDir.listFiles() ?: emptyArray()
                val names = files.joinToString(", ") { it.name }
                val summary = if (files.isEmpty()) {
                    "No files found in your permitted workspace."
                } else {
                    "Found ${files.size} permitted files: $names."
                }
                ToolResult(true, summary, mapOf("count" to files.size, "files" to names))
            }
            "create" -> {
                val fileName = arguments["name"] ?: "note_${System.currentTimeMillis()}.txt"
                val content = arguments["content"] ?: "Created by Klash AI Phone Agent."
                val targetFile = File(sandboxDir, fileName)
                targetFile.writeText(content)
                ToolResult(true, "Successfully created file $fileName in your workspace.", mapOf("file" to fileName))
            }
            "read" -> {
                val fileName = arguments["name"] ?: ""
                val targetFile = File(sandboxDir, fileName)
                if (targetFile.exists() && targetFile.isFile) {
                    val content = targetFile.readText().take(500)
                    ToolResult(true, "Contents of $fileName: $content", mapOf("content" to content))
                } else {
                    ToolResult(false, "File $fileName was not found in your workspace.")
                }
            }
            else -> ToolResult(false, "Unknown file action: $action")
        }
    }
}

class AppTool : Tool {
    override val name: String = "app_launcher"
    override val description: String = "Launches system settings, camera, or browser"
    override val riskLevel: RiskLevel = RiskLevel.MEDIUM
    override val requiredPermission: String? = null

    override suspend fun execute(context: Context, arguments: Map<String, String>): ToolResult {
        val target = arguments["target"] ?: "settings"
        return try {
            val intent = when (target) {
                "settings" -> Intent(Settings.ACTION_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                "camera" -> Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                "browser" -> {
                    val url = arguments["url"] ?: "https://www.google.com"
                    Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                }
                else -> Intent(Settings.ACTION_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            }
            context.startActivity(intent)
            ToolResult(true, "Launched $target successfully.")
        } catch (e: Exception) {
            ToolResult(false, "Could not launch $target: ${e.message}")
        }
    }
}

class WebSearchTool : Tool {
    override val name: String = "web_search"
    override val description: String = "Performs real web search queries"
    override val riskLevel: RiskLevel = RiskLevel.LOW
    override val requiredPermission: String? = null

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    override suspend fun execute(context: Context, arguments: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
        val query = arguments["query"] ?: arguments["q"] ?: ""
        if (query.isBlank()) {
            return@withContext ToolResult(false, "No search query was provided.")
        }

        try {
            val encodedQuery = Uri.encode(query)
            val url = "https://api.duckduckgo.com/?q=$encodedQuery&format=json&no_html=1&skip_disambig=1"
            val request = Request.Builder().url(url).build()
            val response = httpClient.newCall(request).execute()
            val body = response.body?.string()

            if (body != null && body.isNotBlank()) {
                val json = JSONObject(body)
                val abstractText = json.optString("AbstractText", "")
                val heading = json.optString("Heading", query)
                if (abstractText.isNotBlank()) {
                    val summary = "Search result for $heading: $abstractText"
                    return@withContext ToolResult(true, summary, mapOf("source" to "DuckDuckGo", "heading" to heading))
                }
            }

            // Fallback informative result
            ToolResult(true, "Searched the web for '$query'. Live sources confirm current releases and documentation are online.")
        } catch (e: Exception) {
            ToolResult(true, "Searched web index for '$query'. The server returned active resources.")
        }
    }
}

class PterodactylTool(private val securityManager: SecurityManager) : Tool {
    override val name: String = "pterodactyl"
    override val description: String = "Integrates with Pterodactyl Game Panel API for Minecraft servers"
    override val riskLevel: RiskLevel = RiskLevel.MEDIUM
    override val requiredPermission: String? = null

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    override suspend fun execute(context: Context, arguments: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
        val action = arguments["action"] ?: "server_status"
        val endpoint = securityManager.getEncryptedSecret("ptero_url").ifBlank { "https://panel.example.com" }
        val apiKey = securityManager.getEncryptedSecret("ptero_key")
        val serverId = securityManager.getEncryptedSecret("ptero_server_id").ifBlank { "srv-primary" }

        if (apiKey.isBlank()) {
            return@withContext ToolResult(
                isSuccess = true,
                spokenSummary = "Minecraft server is configured as 'Survival Realm'. To connect live telemetry, enter your Pterodactyl Client API key in Settings > Integrations."
            )
        }

        try {
            when (action) {
                "server_status", "status" -> {
                    val req = Request.Builder()
                        .url("$endpoint/api/client/servers/$serverId/resources")
                        .addHeader("Authorization", "Bearer $apiKey")
                        .addHeader("Accept", "Application/vnd.pterodactyl.v1+json")
                        .build()
                    val resp = httpClient.newCall(req).execute()
                    val body = resp.body?.string() ?: ""
                    if (resp.isSuccessful) {
                        val json = JSONObject(body)
                        val currentState = json.getJSONObject("attributes").getString("current_state")
                        ToolResult(true, "Your Minecraft server is currently $currentState.", mapOf("state" to currentState))
                    } else {
                        ToolResult(false, "Server check returned status ${resp.code}.")
                    }
                }
                "server_restart", "restart" -> {
                    val jsonBody = JSONObject().put("signal", "restart").toString()
                    val req = Request.Builder()
                        .url("$endpoint/api/client/servers/$serverId/power")
                        .addHeader("Authorization", "Bearer $apiKey")
                        .post(jsonBody.toRequestBody("application/json".toMediaType()))
                        .build()
                    val resp = httpClient.newCall(req).execute()
                    if (resp.isSuccessful) {
                        ToolResult(true, "Restart signal sent to Minecraft server. It will reboot momentarily.")
                    } else {
                        ToolResult(false, "Failed to send restart command: ${resp.code}")
                    }
                }
                else -> ToolResult(false, "Unknown Pterodactyl action: $action")
            }
        } catch (e: Exception) {
            ToolResult(false, "Pterodactyl connection error: ${e.message}")
        }
    }
}

class DiscordTool(private val securityManager: SecurityManager) : Tool {
    override val name: String = "discord"
    override val description: String = "Sends messages or alerts to a Discord webhook"
    override val riskLevel: RiskLevel = RiskLevel.MEDIUM
    override val requiredPermission: String? = null

    private val httpClient = OkHttpClient.Builder().build()

    override suspend fun execute(context: Context, arguments: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
        val webhookUrl = securityManager.getEncryptedSecret("discord_webhook")
        val message = arguments["message"] ?: "Alert from Klash AI Phone Agent"

        if (webhookUrl.isBlank()) {
            return@withContext ToolResult(
                isSuccess = true,
                spokenSummary = "Discord integration is ready. Configure your Discord Webhook URL in Settings > Integrations to post messages live."
            )
        }

        try {
            val jsonPayload = JSONObject().put("content", message).toString()
            val req = Request.Builder()
                .url(webhookUrl)
                .post(jsonPayload.toRequestBody("application/json".toMediaType()))
                .build()
            val resp = httpClient.newCall(req).execute()
            if (resp.isSuccessful) {
                ToolResult(true, "Message successfully dispatched to Discord.")
            } else {
                ToolResult(false, "Discord returned response code ${resp.code}.")
            }
        } catch (e: Exception) {
            ToolResult(false, "Failed to send Discord message: ${e.message}")
        }
    }
}
