package com.example.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AIResponse(
    val spokenText: String,
    val toolCall: ToolCallRequest? = null,
    val providerUsed: String = "LOCAL_RULE_ENGINE"
)

data class ToolCallRequest(
    val toolName: String,
    val arguments: Map<String, String> = emptyMap()
)

interface AIProvider {
    val providerId: String
    val displayName: String

    suspend fun generateResponse(
        systemInstruction: String,
        history: List<Pair<String, String>>, // role ("user" or "model"), text
        userMessage: String,
        allowedTools: List<String>
    ): AIResponse
}

class GeminiProvider(private val customApiKey: String? = null) : AIProvider {
    override val providerId: String = "GEMINI"
    override val displayName: String = "Google Gemini 3.5 Flash"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    override suspend fun generateResponse(
        systemInstruction: String,
        history: List<Pair<String, String>>,
        userMessage: String,
        allowedTools: List<String>
    ): AIResponse = withContext(Dispatchers.IO) {
        val apiKey = customApiKey?.ifBlank { null } ?: BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            // Graceful fallback to local rule engine when no API key configured
            return@withContext LocalRuleProvider().generateResponse(systemInstruction, history, userMessage, allowedTools)
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

            val contentsArray = JSONArray()
            // History
            for ((role, text) in history.takeLast(6)) {
                contentsArray.put(
                    JSONObject().apply {
                        put("role", if (role == "user") "user" else "model")
                        put("parts", JSONArray().put(JSONObject().put("text", text)))
                    }
                )
            }
            // User current message
            contentsArray.put(
                JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", userMessage)))
                }
            )

            val fullSystemPrompt = "$systemInstruction\n\nYou are a voice phone assistant. Answer in concise spoken sentences. " +
                    "Available tools: ${allowedTools.joinToString(", ")}. " +
                    "If the user asks for RAM, storage, battery, server status, or web search, indicate the tool needed by replying exactly: TOOL_CALL: <tool_name>"

            val rootJson = JSONObject().apply {
                put("contents", contentsArray)
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", fullSystemPrompt)))
                })
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.7)
                    put("maxOutputTokens", 200)
                })
            }

            val requestBody = rootJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder().url(url).post(requestBody).build()
            val response = httpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val json = JSONObject(responseBody)
                val candidates = json.optJSONArray("candidates")
                val firstCandidate = candidates?.optJSONObject(0)
                val content = firstCandidate?.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                val text = parts?.optJSONObject(0)?.optString("text", "") ?: ""

                if (text.startsWith("TOOL_CALL:")) {
                    val toolName = text.removePrefix("TOOL_CALL:").trim()
                    return@withContext AIResponse(
                        spokenText = "Checking $toolName...",
                        toolCall = ToolCallRequest(toolName),
                        providerUsed = "Gemini 3.5 Flash"
                    )
                }

                AIResponse(spokenText = text.trim(), providerUsed = "Gemini 3.5 Flash")
            } else {
                LocalRuleProvider().generateResponse(systemInstruction, history, userMessage, allowedTools)
            }
        } catch (e: Exception) {
            LocalRuleProvider().generateResponse(systemInstruction, history, userMessage, allowedTools)
        }
    }
}

class OpenAICompatibleProvider(
    private val endpointUrl: String,
    private val apiKey: String,
    private val modelName: String = "gpt-4o-mini"
) : AIProvider {
    override val providerId: String = "OPENAI_COMPATIBLE"
    override val displayName: String = "OpenAI Compatible / OpenRouter"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    override suspend fun generateResponse(
        systemInstruction: String,
        history: List<Pair<String, String>>,
        userMessage: String,
        allowedTools: List<String>
    ): AIResponse = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || endpointUrl.isBlank()) {
            return@withContext LocalRuleProvider().generateResponse(systemInstruction, history, userMessage, allowedTools)
        }

        try {
            val messagesArray = JSONArray()
            messagesArray.put(
                JSONObject().put("role", "system").put("content", "$systemInstruction\nAvailable tools: ${allowedTools.joinToString(", ")}. Keep response short for phone audio.")
            )
            for ((role, text) in history.takeLast(6)) {
                messagesArray.put(JSONObject().put("role", role).put("content", text))
            }
            messagesArray.put(JSONObject().put("role", "user").put("content", userMessage))

            val rootJson = JSONObject().apply {
                put("model", modelName)
                put("messages", messagesArray)
                put("max_tokens", 150)
            }

            val request = Request.Builder()
                .url(if (endpointUrl.endsWith("/chat/completions")) endpointUrl else "$endpointUrl/chat/completions")
                .addHeader("Authorization", "Bearer $apiKey")
                .post(rootJson.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (response.isSuccessful) {
                val json = JSONObject(body)
                val choices = json.getJSONArray("choices")
                val reply = choices.getJSONObject(0).getJSONObject("message").getString("content")
                AIResponse(spokenText = reply.trim(), providerUsed = modelName)
            } else {
                LocalRuleProvider().generateResponse(systemInstruction, history, userMessage, allowedTools)
            }
        } catch (e: Exception) {
            LocalRuleProvider().generateResponse(systemInstruction, history, userMessage, allowedTools)
        }
    }
}

class LocalRuleProvider : AIProvider {
    override val providerId: String = "LOCAL_RULE"
    override val displayName: String = "Local Offline Rule Engine"

    override suspend fun generateResponse(
        systemInstruction: String,
        history: List<Pair<String, String>>,
        userMessage: String,
        allowedTools: List<String>
    ): AIResponse {
        val lower = userMessage.lowercase().trim()

        // Natural device tool matching
        if (allowedTools.contains("get_ram") && (lower.contains("ram") || lower.contains("memory"))) {
            return AIResponse("Querying memory metrics...", ToolCallRequest("get_ram"), displayName)
        }
        if (allowedTools.contains("get_storage") && (lower.contains("storage") || lower.contains("disk") || lower.contains("space") || lower.contains("rom"))) {
            return AIResponse("Querying storage metrics...", ToolCallRequest("get_storage"), displayName)
        }
        if (allowedTools.contains("get_battery") && (lower.contains("battery") || lower.contains("charge") || lower.contains("power"))) {
            return AIResponse("Checking battery status...", ToolCallRequest("get_battery"), displayName)
        }
        if (allowedTools.contains("get_network") && (lower.contains("network") || lower.contains("wifi") || lower.contains("cellular") || lower.contains("internet"))) {
            return AIResponse("Checking network connectivity...", ToolCallRequest("get_network"), displayName)
        }
        if (allowedTools.contains("get_device_info") && (lower.contains("device") || lower.contains("phone") || lower.contains("model") || lower.contains("specs"))) {
            return AIResponse("Retrieving device information...", ToolCallRequest("get_device_info"), displayName)
        }
        if (lower.contains("server") || lower.contains("minecraft") || lower.contains("players")) {
            return AIResponse("Checking server status...", ToolCallRequest("server_status"), displayName)
        }
        if (lower.contains("search") || lower.contains("google") || lower.contains("who is") || lower.contains("what is")) {
            val q = lower.replace("search", "").replace("what is", "").replace("who is", "").trim()
            return AIResponse("Searching web sources...", ToolCallRequest("web_search", mapOf("query" to q)), displayName)
        }
        if (lower.contains("hello") || lower.contains("hi") || lower.contains("hey")) {
            return AIResponse("Hello! I am Klash, your phone agent. You can ask me to check RAM, storage, battery, server status, or navigate IVR branches.", null, displayName)
        }
        if (lower.contains("help") || lower.contains("options")) {
            return AIResponse("You can say 'Check my phone', 'Check RAM', 'Battery status', 'Server status', or 'Goodbye'.", null, displayName)
        }
        if (lower.contains("bye") || lower.contains("goodbye") || lower.contains("quit")) {
            return AIResponse("Goodbye! Have a productive day.", ToolCallRequest("end_call"), displayName)
        }

        return AIResponse(
            "I heard: '$userMessage'. You can say 'Check phone', 'RAM', 'Storage', 'Battery', or press 1 through 5 on the keypad.",
            null,
            displayName
        )
    }
}
