package com.example.commands

import android.content.Context
import com.example.tools.ToolRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class WorkflowExecutionResult(
    val spokenOutputs: List<String>,
    val endCallRequested: Boolean,
    val executedTools: List<String>,
    val finalSummary: String
)

class WorkflowEngine(
    private val context: Context,
    private val toolRegistry: ToolRegistry
) {
    suspend fun executeActions(
        actions: List<CommandAction>,
        variables: MutableMap<String, String>,
        callId: Long = 0,
        callerTier: String = "OWNER"
    ): WorkflowExecutionResult = withContext(Dispatchers.IO) {
        val spoken = mutableListOf<String>()
        val executedTools = mutableListOf<String>()
        var endCall = false

        for (action in actions) {
            when (action.actionType.uppercase()) {
                "TOOL" -> {
                    val toolName = resolveVariables(action.name, variables)
                    val result = toolRegistry.executeTool(toolName, emptyMap(), callId, callerTier)
                    executedTools.add(toolName)
                    spoken.add(result.spokenSummary)

                    // Inject tool outputs into variable scope
                    result.rawData.forEach { (k, v) ->
                        if (v != null) variables[k] = v.toString()
                    }
                }
                "SPEAK" -> {
                    val resolvedText = resolveVariables(action.text, variables)
                    spoken.add(resolvedText)
                }
                "SPEAK_SUMMARY" -> {
                    // Combine previous tool outputs into a coherent spoken summary
                    val summaryText = spoken.joinToString(" ")
                    val finalSpoken = if (action.prompt.isNotBlank()) {
                        resolveVariables(action.prompt, variables).let { p ->
                            if (p.isNotBlank() && summaryText.isNotBlank()) summaryText else p
                        }
                    } else summaryText
                    spoken.clear()
                    spoken.add(finalSpoken)
                }
                "END_CALL" -> {
                    endCall = true
                }
            }
        }

        WorkflowExecutionResult(
            spokenOutputs = spoken,
            endCallRequested = endCall,
            executedTools = executedTools,
            finalSummary = spoken.joinToString(" ")
        )
    }

    private fun resolveVariables(template: String, variables: Map<String, String>): String {
        var text = template
        variables.forEach { (k, v) ->
            text = text.replace("{$k}", v)
        }
        return text
    }
}
