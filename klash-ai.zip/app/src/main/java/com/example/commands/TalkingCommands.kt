package com.example.commands

import com.example.database.TalkingCommandEntity
import org.json.JSONArray
import org.json.JSONObject

data class CommandAction(
    val actionType: String, // "TOOL", "SPEAK", "SPEAK_SUMMARY", "END_CALL", "SET_MEMORY"
    val name: String = "",
    val text: String = "",
    val prompt: String = "",
    val key: String = "",
    val value: String = ""
)

object CommandParser {
    fun parseActions(json: String): List<CommandAction> {
        if (json.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            val list = mutableListOf<CommandAction>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    CommandAction(
                        actionType = obj.optString("actionType", "SPEAK"),
                        name = obj.optString("name", ""),
                        text = obj.optString("text", ""),
                        prompt = obj.optString("prompt", ""),
                        key = obj.optString("key", ""),
                        value = obj.optString("value", "")
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun serializeActions(actions: List<CommandAction>): String {
        val arr = JSONArray()
        for (a in actions) {
            val obj = JSONObject().apply {
                put("actionType", a.actionType)
                put("name", a.name)
                put("text", a.text)
                put("prompt", a.prompt)
                put("key", a.key)
                put("value", a.value)
            }
            arr.put(obj)
        }
        return arr.toString()
    }
}

class CommandMatcher {
    fun findMatchingCommand(
        input: String,
        commands: List<TalkingCommandEntity>
    ): TalkingCommandEntity? {
        val cleanInput = input.lowercase().trim()
        if (cleanInput.isBlank()) return null

        // 1. Exact match on triggerPhrase
        val exact = commands.firstOrNull { it.triggerPhrase.equals(cleanInput, ignoreCase = true) }
        if (exact != null) return exact

        // 2. Check aliases
        for (cmd in commands) {
            val aliasList = cmd.aliases.split(",").map { it.trim().lowercase() }
            if (aliasList.any { it.isNotBlank() && (cleanInput == it || cleanInput.contains(it)) }) {
                return cmd
            }
        }

        // 3. Natural / Keyword containment
        for (cmd in commands) {
            if (cmd.matchingMode == "BOTH" || cmd.matchingMode == "AI") {
                val triggerWords = cmd.triggerPhrase.lowercase().split(" ").filter { it.length > 2 }
                if (triggerWords.isNotEmpty() && triggerWords.all { cleanInput.contains(it) }) {
                    return cmd
                }
            }
        }

        return null
    }
}
