package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonCyan = Color(0xFF00E5FF)
val NeonCyanDark = Color(0xFF0097A7)
val ElectricPurple = Color(0xFFA855F7)
val CyberPink = Color(0xFFEC4899)
val CyberGreen = Color(0xFF10B981)
val CyberAmber = Color(0xFFF59E0B)
val CyberRed = Color(0xFFEF4444)

val DarkBackground = Color(0xFF070B14)
val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkBorder = Color(0xFF334155)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
