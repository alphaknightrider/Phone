package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.AgentCore
import com.example.agent.CallState
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class ChatMessage(
    val sender: String, // "Caller" or "Klash AI" or "System"
    val text: String,
    val time: Long = System.currentTimeMillis()
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestCallScreen(
    agentCore: AgentCore,
    configuredPhoneNumber: String,
    onBack: () -> Unit
) {
    val callState by agentCore.callState.collectAsState()
    val activeProfile by agentCore.activeProfile.collectAsState()
    val transcript by agentCore.liveTranscript.collectAsState()
    val lastAiResponse by agentCore.lastAiResponse.collectAsState()

    var showKeypad by remember { mutableStateOf(false) }
    var textInput by remember { mutableStateOf("") }
    var isMuted by remember { mutableStateOf(false) }
    var isSpeakerOn by remember { mutableStateOf(true) }
    var callDurationSeconds by remember { mutableIntStateOf(0) }

    val messages = remember { mutableStateListOf<ChatMessage>() }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // Audio permission launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            agentCore.startCall(
                callerNumber = configuredPhoneNumber.ifBlank { "+15550001234" },
                callerName = "Owner Simulator",
                transportMode = "VOIP_MEDIA"
            )
        }
    }

    // Call timer
    LaunchedEffect(callState) {
        if (callState == CallState.ACTIVE || callState == CallState.SPEAKING || callState == CallState.LISTENING) {
            while (true) {
                delay(1000)
                callDurationSeconds++
            }
        } else {
            callDurationSeconds = 0
        }
    }

    // Update messages from transcripts
    LaunchedEffect(transcript) {
        if (transcript.isNotBlank()) {
            messages.add(ChatMessage("Caller", transcript))
            scope.launch { listState.animateScrollToItem((messages.size - 1).coerceAtLeast(0)) }
        }
    }

    LaunchedEffect(lastAiResponse) {
        if (lastAiResponse.isNotBlank()) {
            messages.add(ChatMessage("Klash AI", lastAiResponse))
            scope.launch { listState.animateScrollToItem((messages.size - 1).coerceAtLeast(0)) }
        }
    }

    // Auto start call when screen opens
    LaunchedEffect(Unit) {
        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    // Visual pulse animation for active audio
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Live AI Voice Call", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(
                            text = "${activeProfile?.name ?: "Klash AI"} • ${String.format("%02d:%02d", callDurationSeconds / 60, callDurationSeconds % 60)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = NeonCyan
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        agentCore.endCall()
                        onBack()
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        isSpeakerOn = !isSpeakerOn
                        agentCore.audioSessionManager.setSpeakerphone(isSpeakerOn)
                    }) {
                        Icon(
                            if (isSpeakerOn) Icons.AutoMirrored.Filled.VolumeUp else Icons.Default.VolumeMute,
                            contentDescription = "Speaker",
                            tint = if (isSpeakerOn) NeonCyan else TextMuted
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = TextPrimary
                )
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // HUD Status Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Brush.horizontalGradient(listOf(NeonCyan.copy(alpha = 0.5f), ElectricPurple.copy(alpha = 0.5f))), RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .scale(if (callState == CallState.SPEAKING || callState == CallState.LISTENING) pulseScale else 1.0f)
                            .clip(CircleShape)
                            .background(
                                when (callState) {
                                    CallState.SPEAKING -> NeonCyan.copy(alpha = 0.25f)
                                    CallState.LISTENING -> CyberGreen.copy(alpha = 0.25f)
                                    CallState.THINKING -> ElectricPurple.copy(alpha = 0.25f)
                                    CallState.EXECUTING -> CyberAmber.copy(alpha = 0.25f)
                                    else -> DarkBorder
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (callState) {
                                CallState.SPEAKING -> Icons.AutoMirrored.Filled.VolumeUp
                                CallState.LISTENING -> Icons.Default.Mic
                                CallState.THINKING -> Icons.Default.Psychology
                                CallState.EXECUTING -> Icons.Default.Build
                                else -> Icons.Default.Phone
                            },
                            contentDescription = null,
                            tint = when (callState) {
                                CallState.SPEAKING -> NeonCyan
                                CallState.LISTENING -> CyberGreen
                                CallState.THINKING -> ElectricPurple
                                CallState.EXECUTING -> CyberAmber
                                else -> TextMuted
                            },
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "STATE: ${callState.name}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 2.sp,
                            color = when (callState) {
                                CallState.SPEAKING -> NeonCyan
                                CallState.LISTENING -> CyberGreen
                                CallState.THINKING -> ElectricPurple
                                CallState.EXECUTING -> CyberAmber
                                else -> TextPrimary
                            }
                        )
                    )

                    Text(
                        text = when (callState) {
                            CallState.SPEAKING -> "Klash is speaking. Tap 'Interrupt' or speak to barge-in."
                            CallState.LISTENING -> "Listening to your voice through microphone..."
                            CallState.THINKING -> "Routing intent through AI & tool planner..."
                            CallState.EXECUTING -> "Executing requested device tool action..."
                            else -> "Call ready."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )

                    if (callState == CallState.SPEAKING) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { agentCore.ttsEngine.stop() },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberPink),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("barge_in_button")
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Barge-in / Interrupt AI", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Quick Talking Action Shortcuts
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                AssistChip(
                    onClick = { agentCore.handleUserInput("Check my phone") },
                    label = { Text("Check phone", fontSize = 11.sp) }
                )
                AssistChip(
                    onClick = { agentCore.handleUserInput("1") },
                    label = { Text("Press 1 (AI)", fontSize = 11.sp) }
                )
                AssistChip(
                    onClick = { agentCore.handleUserInput("2") },
                    label = { Text("Press 2 (RAM/Phone)", fontSize = 11.sp) }
                )
                AssistChip(
                    onClick = { agentCore.handleUserInput("Check my server") },
                    label = { Text("Server status", fontSize = 11.sp) }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Real-Time Transcript Feed
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
                    .background(DarkSurface)
                    .padding(12.dp),
                state = listState,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (messages.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Conversation transcript will appear here in real-time...", color = TextMuted)
                        }
                    }
                }
                items(messages) { msg ->
                    val isUser = msg.sender == "Caller"
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                    ) {
                        Text(
                            text = msg.sender,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isUser) CyberGreen else NeonCyan
                            )
                        )
                        Surface(
                            color = if (isUser) DarkSurfaceVariant else Color(0xFF00363D),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            Text(
                                text = msg.text,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Text Fallback & Keypad Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = { Text("Type voice/DTMF command...") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = DarkBorder
                    )
                )

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = {
                        if (textInput.isNotBlank()) {
                            agentCore.handleUserInput(textInput)
                            textInput = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(NeonCyan)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color(0xFF001F29))
                }

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = { showKeypad = !showKeypad },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant)
                ) {
                    Icon(Icons.Default.Dialpad, contentDescription = "Dialpad", tint = NeonCyan)
                }
            }

            // Keypad modal/sheet if toggled
            if (showKeypad) {
                Spacer(modifier = Modifier.height(8.dp))
                IvrDialpad(
                    onDigitPressed = { digit ->
                        agentCore.handleUserInput(digit)
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Hang Up Action
            Button(
                onClick = {
                    agentCore.endCall("Thank you for using Klash AI.")
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("end_call_button"),
                colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.CallEnd, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("DISCONNECT / END CALL", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
fun IvrDialpad(onDigitPressed: (String) -> Unit) {
    val digits = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf("*", "0", "#")
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            digits.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    row.forEach { digit ->
                        FilledTonalButton(
                            onClick = { onDigitPressed(digit) },
                            modifier = Modifier
                                .size(56.dp)
                                .testTag("dtmf_btn_$digit"),
                            shape = CircleShape,
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = DarkSurfaceVariant,
                                contentColor = NeonCyan
                            )
                        ) {
                            Text(digit, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
