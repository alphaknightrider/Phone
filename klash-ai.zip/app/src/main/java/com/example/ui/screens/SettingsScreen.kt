package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.KlashApplication
import com.example.ai.AIProvider
import com.example.ai.GeminiProvider
import com.example.ai.LocalRuleProvider
import com.example.ai.OpenAICompatibleProvider
import com.example.telecom.PhoneAccountManager
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    currentProvider: AIProvider,
    onSelectProvider: (AIProvider) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as KlashApplication
    val secMgr = app.securityManager
    val phoneAccountMgr = remember { PhoneAccountManager(context) }
    val scrollState = rememberScrollState()

    var selectedProviderType by remember {
        mutableStateOf(currentProvider.providerId)
    }

    var customGeminiKey by remember { mutableStateOf(secMgr.getEncryptedSecret("custom_gemini_key")) }
    var openaiUrl by remember { mutableStateOf(secMgr.getEncryptedSecret("openai_url").ifBlank { "https://openrouter.ai/api/v1" }) }
    var openaiKey by remember { mutableStateOf(secMgr.getEncryptedSecret("openai_key")) }
    var openaiModel by remember { mutableStateOf(secMgr.getEncryptedSecret("openai_model").ifBlank { "meta-llama/llama-3.1-8b-instruct:free" }) }

    var ownerPin by remember { mutableStateOf("") }
    var pinMessage by remember { mutableStateOf("") }

    val isDialerRole = remember { phoneAccountMgr.isDefaultDialer() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings & Telephony Architecture", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = TextPrimary
                )
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // AI Provider Selection
            Text(
                text = "AI INTELLIGENCE PROVIDER",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.5.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Select which AI engine powers natural conversation:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = selectedProviderType == "GEMINI",
                            onClick = {
                                selectedProviderType = "GEMINI"
                                onSelectProvider(GeminiProvider(customGeminiKey))
                            },
                            label = { Text("Gemini 3.5") }
                        )
                        FilterChip(
                            selected = selectedProviderType == "OPENAI_COMPATIBLE",
                            onClick = {
                                selectedProviderType = "OPENAI_COMPATIBLE"
                                onSelectProvider(OpenAICompatibleProvider(openaiUrl, openaiKey, openaiModel))
                            },
                            label = { Text("OpenAI / OpenRouter") }
                        )
                        FilterChip(
                            selected = selectedProviderType == "LOCAL_RULE",
                            onClick = {
                                selectedProviderType = "LOCAL_RULE"
                                onSelectProvider(LocalRuleProvider())
                            },
                            label = { Text("Local Offline (No API)") }
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (selectedProviderType == "GEMINI") {
                        OutlinedTextField(
                            value = customGeminiKey,
                            onValueChange = { customGeminiKey = it },
                            label = { Text("Custom Gemini API Key (Optional override)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Default key is auto-injected from AI Studio Secrets panel.", style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp), color = TextMuted)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(onClick = {
                            secMgr.saveEncryptedSecret("custom_gemini_key", customGeminiKey)
                            onSelectProvider(GeminiProvider(customGeminiKey))
                        }) { Text("Save Gemini Key") }
                    } else if (selectedProviderType == "OPENAI_COMPATIBLE") {
                        OutlinedTextField(
                            value = openaiUrl,
                            onValueChange = { openaiUrl = it },
                            label = { Text("Base Endpoint URL") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = openaiModel,
                            onValueChange = { openaiModel = it },
                            label = { Text("Model Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = openaiKey,
                            onValueChange = { openaiKey = it },
                            label = { Text("API Key (Stored in Keystore)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(onClick = {
                            secMgr.saveEncryptedSecret("openai_url", openaiUrl)
                            secMgr.saveEncryptedSecret("openai_model", openaiModel)
                            secMgr.saveEncryptedSecret("openai_key", openaiKey)
                            onSelectProvider(OpenAICompatibleProvider(openaiUrl, openaiKey, openaiModel))
                        }) { Text("Save OpenAI Config") }
                    } else {
                        Text(
                            "Local Rule Engine executes 100% on-device with zero network latency, zero costs, and no VPS or third-party cloud required.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberGreen
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Telephony Architecture & Limitations Transparency Card
            Text(
                text = "TELEPHONY ARCHITECTURE TRANSPARENCY",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.5.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = NeonCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Android Telephony Modes", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "1. SIM / Telecom Mode (InCallService):\n" +
                                "Standard Android Telecom security strictly protects cellular SIM voice calls from unauthorized raw audio interception. In this mode, Klash acts as a legitimate InCallService to control call answering, DTMF, state notifications, and screening.\n\n" +
                                "2. Two-Way AI Voice Media Mode (ConnectionService & VoIP):\n" +
                                "For live two-way AI speech synthesis, audio streaming, and voice commands, Klash AI utilizes ConnectionService and standard VoIP/SIP media endpoints. The core AI Agent Core seamlessly routes inputs across either transport.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isDialerRole) "Status: Dialer Role Granted" else "Dialer Role: Companion / Standalone",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = if (isDialerRole) CyberGreen else TextMuted
                        )
                        Button(
                            onClick = { phoneAccountMgr.registerPhoneAccount() },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color(0xFF001F29))
                        ) {
                            Text("Register PhoneAccount")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Security PIN Protection
            Text(
                text = "OWNER ACCESS CONTROL PIN",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.5.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Protect Call-Flow modifications and API tokens with an Owner PIN:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = ownerPin,
                        onValueChange = { if (it.length <= 6) ownerPin = it },
                        label = { Text("4-6 Digit Security PIN") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            if (ownerPin.length >= 4) {
                                secMgr.setOwnerPin(ownerPin)
                                pinMessage = "Owner PIN successfully updated and secured."
                            } else {
                                pinMessage = "PIN must be at least 4 digits."
                            }
                        }
                    ) { Text("Set Owner PIN") }

                    if (pinMessage.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(pinMessage, style = MaterialTheme.typography.bodySmall, color = CyberGreen)
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
