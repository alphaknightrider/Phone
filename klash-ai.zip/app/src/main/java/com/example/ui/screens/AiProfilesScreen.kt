package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.database.AIProfileEntity
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiProfilesScreen(
    profiles: List<AIProfileEntity>,
    onSaveProfile: (AIProfileEntity) -> Unit,
    onDeleteProfile: (Long) -> Unit,
    onBack: () -> Unit
) {
    var selectedProfileForEdit by remember { mutableStateOf<AIProfileEntity?>(null) }
    var showEditDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Personas & Voices", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = TextPrimary
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    selectedProfileForEdit = null
                    showEditDialog = true
                },
                containerColor = ElectricPurple,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_ai_profile_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "New AI Profile")
            }
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Each IVR branch can be assigned a dedicated persona with independent instructions, tools, and voice traits.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(profiles, key = { it.id }) { profile ->
                    AIProfileCard(
                        profile = profile,
                        onEdit = {
                            selectedProfileForEdit = profile
                            showEditDialog = true
                        },
                        onDelete = {
                            if (!profile.isDefault) {
                                onDeleteProfile(profile.id)
                            }
                        }
                    )
                }
                item { Spacer(modifier = Modifier.height(80.dp)) }
            }
        }
    }

    if (showEditDialog) {
        AIProfileEditorDialog(
            profile = selectedProfileForEdit,
            onDismiss = { showEditDialog = false },
            onSave = {
                onSaveProfile(it)
                showEditDialog = false
            }
        )
    }
}

@Composable
fun AIProfileCard(
    profile: AIProfileEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (profile.isDefault) NeonCyan.copy(alpha = 0.5f) else DarkBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onEdit),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Psychology, contentDescription = null, tint = ElectricPurple)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = profile.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimary
                    )
                    if (profile.isDefault) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = NeonCyan.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                "DEFAULT",
                                color = NeonCyan,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Surface(
                    color = DarkBorder,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = profile.language,
                        color = TextSecondary,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Tone: ${profile.personality}",
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                color = ElectricPurple
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = profile.instructions,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Allowed Tools: ${profile.allowedTools}",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = TextMuted,
                maxLines = 1
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = TextSecondary, modifier = Modifier.size(16.dp))
                }
                if (!profile.isDefault) {
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CyberRed.copy(alpha = 0.8f), modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun AIProfileEditorDialog(
    profile: AIProfileEntity?,
    onDismiss: () -> Unit,
    onSave: (AIProfileEntity) -> Unit
) {
    var name by remember { mutableStateOf(profile?.name ?: "") }
    var personality by remember { mutableStateOf(profile?.personality ?: "Professional, helpful, and concise") }
    var instructions by remember { mutableStateOf(profile?.instructions ?: "You are a personal phone assistant.") }
    var language by remember { mutableStateOf(profile?.language ?: "en-US") }
    var speechRate by remember { mutableFloatStateOf(profile?.speechRate ?: 1.0f) }
    var speechPitch by remember { mutableFloatStateOf(profile?.speechPitch ?: 1.0f) }
    var allowedTools by remember { mutableStateOf(profile?.allowedTools ?: "get_ram,get_storage,get_battery,get_network,web_search") }
    var isDefault by remember { mutableStateOf(profile?.isDefault ?: false) }

    val languages = listOf("en-US", "hi-IN", "hi-Latn")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (profile == null) "Create AI Persona" else "Edit Persona") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Persona Name (e.g. Klash, Tech Support)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = personality,
                    onValueChange = { personality = it },
                    label = { Text("Tone / Personality") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = instructions,
                    onValueChange = { instructions = it },
                    label = { Text("System Instructions") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                Text("Spoken Language:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    languages.forEach { l ->
                        FilterChip(
                            selected = language == l,
                            onClick = { language = l },
                            label = { Text(l) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text("Speech Rate: ${"%.1f".format(speechRate)}x", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = speechRate,
                    onValueChange = { speechRate = it },
                    valueRange = 0.7f..1.5f,
                    steps = 8
                )

                Text("Speech Pitch: ${"%.1f".format(speechPitch)}x", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = speechPitch,
                    onValueChange = { speechPitch = it },
                    valueRange = 0.7f..1.5f,
                    steps = 8
                )

                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = allowedTools,
                    onValueChange = { allowedTools = it },
                    label = { Text("Allowed Tools (comma-separated)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isDefault, onCheckedChange = { isDefault = it })
                    Text("Set as default AI persona", style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updated = profile?.copy(
                        name = name.ifBlank { "Assistant" },
                        personality = personality,
                        instructions = instructions,
                        language = language,
                        speechRate = speechRate,
                        speechPitch = speechPitch,
                        allowedTools = allowedTools,
                        isDefault = isDefault
                    ) ?: AIProfileEntity(
                        id = System.currentTimeMillis(),
                        name = name.ifBlank { "Assistant" },
                        personality = personality,
                        instructions = instructions,
                        language = language,
                        speechRate = speechRate,
                        speechPitch = speechPitch,
                        allowedTools = allowedTools,
                        isDefault = isDefault
                    )
                    onSave(updated)
                }
            ) { Text("Save Persona") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
