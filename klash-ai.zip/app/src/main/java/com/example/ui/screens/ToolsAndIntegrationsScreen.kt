package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.KlashApplication
import com.example.tools.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolsAndIntegrationsScreen(
    toolRegistry: ToolRegistry,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    var ramSummary by remember { mutableStateOf("Tap to query RAM") }
    var storageSummary by remember { mutableStateOf("Tap to query Storage") }
    var batterySummary by remember { mutableStateOf("Tap to query Battery") }
    var networkSummary by remember { mutableStateOf("Tap to query Network") }
    var deviceSummary by remember { mutableStateOf("Tap to query Device") }

    val app = context.applicationContext as KlashApplication
    val secMgr = app.securityManager

    // Integration States
    var pteroUrl by remember { mutableStateOf(secMgr.getEncryptedSecret("ptero_url").ifBlank { "https://panel.example.com" }) }
    var pteroKey by remember { mutableStateOf(secMgr.getEncryptedSecret("ptero_key")) }
    var pteroServerId by remember { mutableStateOf(secMgr.getEncryptedSecret("ptero_server_id").ifBlank { "srv-primary" }) }
    var pteroTestResult by remember { mutableStateOf("") }

    var discordWebhook by remember { mutableStateOf(secMgr.getEncryptedSecret("discord_webhook")) }
    var discordTestResult by remember { mutableStateOf("") }

    var searchQuery by remember { mutableStateOf("Latest Minecraft update") }
    var searchResult by remember { mutableStateOf("") }

    // Sandbox File state
    var newFileName by remember { mutableStateOf("notes.txt") }
    var newFileContent by remember { mutableStateOf("Klash AI phone agent workspace note.") }
    var fileResult by remember { mutableStateOf("") }

    // Auto load diagnostics on entry
    LaunchedEffect(Unit) {
        scope.launch {
            ramSummary = toolRegistry.executeTool("get_ram").spokenSummary
            storageSummary = toolRegistry.executeTool("get_storage").spokenSummary
            batterySummary = toolRegistry.executeTool("get_battery").spokenSummary
            networkSummary = toolRegistry.executeTool("get_network").spokenSummary
            deviceSummary = toolRegistry.executeTool("get_device_info").spokenSummary
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Phone Tools & Integrations", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = TextPrimary
                )
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            Text(
                text = "REAL HARDWARE TELEMETRY TOOLS",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.5.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Hardware telemetry chips
            TelemetryCard("Device Info", deviceSummary, Icons.Default.PhoneAndroid, NeonCyan)
            Spacer(modifier = Modifier.height(8.dp))
            TelemetryCard("RAM Memory", ramSummary, Icons.Default.Memory, ElectricPurple)
            Spacer(modifier = Modifier.height(8.dp))
            TelemetryCard("Device Storage", storageSummary, Icons.Default.Storage, CyberPink)
            Spacer(modifier = Modifier.height(8.dp))
            TelemetryCard("Battery Status", batterySummary, Icons.Default.BatteryChargingFull, CyberGreen)
            Spacer(modifier = Modifier.height(8.dp))
            TelemetryCard("Network Telemetry", networkSummary, Icons.Default.Wifi, CyberAmber)

            Spacer(modifier = Modifier.height(20.dp))

            // Permitted File Sandbox
            Text(
                text = "PERMITTED FILE SANDBOX (WORKSPACE)",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.5.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Workspace Directory: /data/data/.../klash_workspace", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = newFileName,
                            onValueChange = { newFileName = it },
                            label = { Text("File Name") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = newFileContent,
                        onValueChange = { newFileContent = it },
                        label = { Text("Content") },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                scope.launch {
                                    val r = toolRegistry.executeTool("permitted_files", mapOf("action" to "create", "name" to newFileName, "content" to newFileContent))
                                    fileResult = r.spokenSummary
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberGreen)
                        ) { Text("Create File") }

                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    val r = toolRegistry.executeTool("permitted_files", mapOf("action" to "list"))
                                    fileResult = r.spokenSummary
                                }
                            }
                        ) { Text("List Files") }
                    }

                    if (fileResult.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(fileResult, style = MaterialTheme.typography.bodySmall, color = CyberGreen)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Web Search Tool Tester
            Text(
                text = "LIVE WEB SEARCH GATEWAY",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.5.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            label = { Text("Query") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                scope.launch {
                                    searchResult = "Searching..."
                                    val r = toolRegistry.executeTool("web_search", mapOf("query" to searchQuery))
                                    searchResult = r.spokenSummary
                                }
                            }
                        ) { Text("Search") }
                    }
                    if (searchResult.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(searchResult, style = MaterialTheme.typography.bodySmall, color = NeonCyan)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Pterodactyl Integration
            Text(
                text = "PTERODACTYL MINECRAFT PANEL INTEGRATION",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.5.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    OutlinedTextField(
                        value = pteroUrl,
                        onValueChange = { pteroUrl = it },
                        label = { Text("Panel Base URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = pteroServerId,
                        onValueChange = { pteroServerId = it },
                        label = { Text("Server Identifier (e.g. srv-12345)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = pteroKey,
                        onValueChange = { pteroKey = it },
                        label = { Text("Client API Key (Stored in Keystore)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                secMgr.saveEncryptedSecret("ptero_url", pteroUrl)
                                secMgr.saveEncryptedSecret("ptero_key", pteroKey)
                                secMgr.saveEncryptedSecret("ptero_server_id", pteroServerId)
                                pteroTestResult = "Credentials securely encrypted in Android Keystore."
                            }
                        ) { Text("Save Config") }

                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    val r = toolRegistry.executeTool("server_status")
                                    pteroTestResult = r.spokenSummary
                                }
                            }
                        ) { Text("Test Check") }
                    }

                    if (pteroTestResult.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(pteroTestResult, style = MaterialTheme.typography.bodySmall, color = CyberGreen)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Discord Webhook Integration
            Text(
                text = "DISCORD WEBHOOK INTEGRATION",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.5.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    OutlinedTextField(
                        value = discordWebhook,
                        onValueChange = { discordWebhook = it },
                        label = { Text("Discord Webhook URL (Keystore encrypted)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                secMgr.saveEncryptedSecret("discord_webhook", discordWebhook)
                                discordTestResult = "Webhook URL saved."
                            }
                        ) { Text("Save Webhook") }

                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    val r = toolRegistry.executeTool("discord", mapOf("message" to "Hello from Klash AI Agent!"))
                                    discordTestResult = r.spokenSummary
                                }
                            }
                        ) { Text("Send Test Alert") }
                    }

                    if (discordTestResult.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(discordTestResult, style = MaterialTheme.typography.bodySmall, color = CyberGreen)
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun TelemetryCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: androidx.compose.ui.graphics.Color
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(modifier = Modifier.height(2.dp))
                Text(value, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
        }
    }
}
