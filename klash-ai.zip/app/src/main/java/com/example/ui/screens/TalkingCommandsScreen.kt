package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.commands.CommandAction
import com.example.commands.CommandParser
import com.example.database.TalkingCommandEntity
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TalkingCommandsScreen(
    commands: List<TalkingCommandEntity>,
    onSaveCommand: (TalkingCommandEntity) -> Unit,
    onDeleteCommand: (Long) -> Unit,
    onBack: () -> Unit
) {
    var selectedCommandForEdit by remember { mutableStateOf<TalkingCommandEntity?>(null) }
    var showEditDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Custom Talking Commands", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = TextPrimary
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    selectedCommandForEdit = null
                    showEditDialog = true
                },
                containerColor = CyberPink,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_command_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create Talking Command")
            }
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Define triggers and multi-tool action pipelines with natural speech matching and risk confirmation.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(commands, key = { it.id }) { cmd ->
                    CommandCard(
                        command = cmd,
                        onEdit = {
                            selectedCommandForEdit = cmd
                            showEditDialog = true
                        },
                        onDelete = {
                            onDeleteCommand(cmd.id)
                        }
                    )
                }
                item { Spacer(modifier = Modifier.height(80.dp)) }
            }
        }
    }

    if (showEditDialog) {
        CommandEditorDialog(
            command = selectedCommandForEdit,
            onDismiss = { showEditDialog = false },
            onSave = {
                onSaveCommand(it)
                showEditDialog = false
            }
        )
    }
}

@Composable
fun CommandCard(
    command: TalkingCommandEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val actions = remember(command.actionsJson) { CommandParser.parseActions(command.actionsJson) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onEdit),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = CyberPink)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "«${command.triggerPhrase}»",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimary
                    )
                }

                Surface(
                    color = CyberPink.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = command.matchingMode,
                        color = CyberPink,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            if (command.aliases.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Aliases: ${command.aliases}",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = TextMuted
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Pipeline Actions (${actions.size}):",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(4.dp))

            actions.forEachIndexed { index, act ->
                Row(
                    modifier = Modifier.padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${index + 1}. ",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = NeonCyan
                    )
                    Text(
                        text = when (act.actionType) {
                            "TOOL" -> "Tool: ${act.name}"
                            "SPEAK" -> "Speak: «${act.text}»"
                            "SPEAK_SUMMARY" -> "Generate & Speak Summary"
                            "END_CALL" -> "End Call"
                            else -> act.actionType
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = TextSecondary, modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CyberRed.copy(alpha = 0.8f), modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun CommandEditorDialog(
    command: TalkingCommandEntity?,
    onDismiss: () -> Unit,
    onSave: (TalkingCommandEntity) -> Unit
) {
    var trigger by remember { mutableStateOf(command?.triggerPhrase ?: "") }
    var aliases by remember { mutableStateOf(command?.aliases ?: "") }
    var matchingMode by remember { mutableStateOf(command?.matchingMode ?: "BOTH") }
    var confirmationPolicy by remember { mutableStateOf(command?.confirmationPolicy ?: "NOT_REQUIRED") }
    var actions by remember {
        mutableStateOf(
            if (command != null) CommandParser.parseActions(command.actionsJson).toMutableList()
            else mutableListOf(
                CommandAction("TOOL", name = "get_ram"),
                CommandAction("TOOL", name = "get_storage"),
                CommandAction("SPEAK_SUMMARY")
            )
        )
    }

    val matchingModes = listOf("EXACT", "AI", "BOTH")
    val confirmationPolicies = listOf("NOT_REQUIRED", "ASK_CONFIRMATION", "STRONG_CONFIRMATION")
    val availableTools = listOf("get_ram", "get_storage", "get_battery", "get_network", "get_device_info", "server_status", "player_count", "server_restart", "web_search")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (command == null) "Create Talking Command" else "Edit Talking Command") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = trigger,
                    onValueChange = { trigger = it },
                    label = { Text("Spoken Trigger (e.g. Check my phone)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = aliases,
                    onValueChange = { aliases = it },
                    label = { Text("Alternative Variations (comma-separated)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                Text("Matching Mode:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    matchingModes.forEach { mode ->
                        FilterChip(
                            selected = matchingMode == mode,
                            onClick = { matchingMode = mode },
                            label = { Text(if (mode == "BOTH") "AI + Exact" else mode) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text("Action Pipeline (${actions.size}):", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))

                actions.forEachIndexed { i, act ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${i + 1}. ${act.actionType} ${if (act.name.isNotBlank()) "(${act.name})" else ""}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            IconButton(
                                onClick = {
                                    val list = actions.toMutableList()
                                    list.removeAt(i)
                                    actions = list
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Remove", tint = CyberRed, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Quick add tool actions
                Text("Add Action to Pipeline:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    availableTools.take(3).forEach { tool ->
                        AssistChip(
                            onClick = {
                                val list = actions.toMutableList()
                                list.add(CommandAction("TOOL", name = tool))
                                actions = list
                            },
                            label = { Text(tool.removePrefix("get_"), fontSize = 10.sp) }
                        )
                    }
                    AssistChip(
                        onClick = {
                            val list = actions.toMutableList()
                            list.add(CommandAction("SPEAK_SUMMARY"))
                            actions = list
                        },
                        label = { Text("Summary", fontSize = 10.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text("Confirmation Rule:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    confirmationPolicies.forEach { policy ->
                        FilterChip(
                            selected = confirmationPolicy == policy,
                            onClick = { confirmationPolicy = policy },
                            label = { Text(policy.replace("_", " "), fontSize = 10.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalCmd = command?.copy(
                        triggerPhrase = trigger.ifBlank { "Command" },
                        aliases = aliases,
                        matchingMode = matchingMode,
                        actionsJson = CommandParser.serializeActions(actions),
                        confirmationPolicy = confirmationPolicy
                    ) ?: TalkingCommandEntity(
                        id = System.currentTimeMillis(),
                        triggerPhrase = trigger.ifBlank { "Command" },
                        aliases = aliases,
                        matchingMode = matchingMode,
                        actionsJson = CommandParser.serializeActions(actions),
                        confirmationPolicy = confirmationPolicy
                    )
                    onSave(finalCmd)
                }
            ) { Text("Save Command") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
