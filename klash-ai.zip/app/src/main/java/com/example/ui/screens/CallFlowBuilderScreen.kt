package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.database.AIProfileEntity
import com.example.database.CallFlowEntity
import com.example.database.IvrNodeEntity
import com.example.ui.theme.*
import org.json.JSONArray
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallFlowBuilderScreen(
    flows: List<CallFlowEntity>,
    activeFlow: CallFlowEntity?,
    nodes: List<IvrNodeEntity>,
    aiProfiles: List<AIProfileEntity>,
    onSelectFlow: (CallFlowEntity) -> Unit,
    onSaveNode: (IvrNodeEntity) -> Unit,
    onDeleteNode: (Long) -> Unit,
    onImportFlowJson: (String) -> Unit,
    onBack: () -> Unit
) {
    var selectedNodeForEdit by remember { mutableStateOf<IvrNodeEntity?>(null) }
    var showAddNodeDialog by remember { mutableStateOf(false) }
    var showExportImportDialog by remember { mutableStateOf(false) }
    var jsonText by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Visual Call-Flow Builder", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        // Export current nodes to JSON
                        val arr = JSONArray()
                        for (n in nodes) {
                            arr.put(JSONObject().apply {
                                put("id", n.id)
                                put("nodeType", n.nodeType)
                                put("title", n.title)
                                put("messagePrompt", n.messagePrompt)
                                put("dtmfKey", n.dtmfKey)
                                put("speechKeywords", n.speechKeywords)
                                put("parentNodeId", n.parentNodeId)
                                put("aiProfileId", n.aiProfileId)
                                put("toolName", n.toolName)
                            })
                        }
                        jsonText = arr.toString(2)
                        showExportImportDialog = true
                    }) {
                        Icon(Icons.Default.Code, contentDescription = "Import / Export JSON")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = TextPrimary
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    selectedNodeForEdit = null
                    showAddNodeDialog = true
                },
                containerColor = NeonCyan,
                contentColor = Color(0xFF001F29),
                modifier = Modifier.testTag("add_node_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add IVR Node")
            }
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Current Flow Selector / Header
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.AccountTree, contentDescription = null, tint = NeonCyan)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = activeFlow?.name ?: "Main Call Flow",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary
                        )
                        Text(
                            text = "${nodes.size} Nodes • Unlimited Nested Branches • Hybrid DTMF + Voice",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "IVR MENU ARCHITECTURE & TREE",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.5.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (nodes.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No nodes found for this flow. Click + to add your first node.", color = TextMuted)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(nodes, key = { it.id }) { node ->
                        IvrNodeCard(
                            node = node,
                            onEdit = {
                                selectedNodeForEdit = node
                                showAddNodeDialog = true
                            },
                            onDelete = {
                                onDeleteNode(node.id)
                            }
                        )
                    }
                    item { Spacer(modifier = Modifier.height(80.dp)) }
                }
            }
        }
    }

    if (showAddNodeDialog) {
        NodeEditorDialog(
            node = selectedNodeForEdit,
            existingNodes = nodes,
            aiProfiles = aiProfiles,
            onDismiss = { showAddNodeDialog = false },
            onSave = { updated ->
                onSaveNode(updated)
                showAddNodeDialog = false
            }
        )
    }

    if (showExportImportDialog) {
        AlertDialog(
            onDismissRequest = { showExportImportDialog = false },
            title = { Text("Call Flow JSON") },
            text = {
                Column {
                    Text(
                        "You can copy this JSON to back up the flow, or paste an external flow schema to import it:",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = jsonText,
                        onValueChange = { jsonText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp),
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    onImportFlowJson(jsonText)
                    showExportImportDialog = false
                }) { Text("Import & Apply") }
            },
            dismissButton = {
                TextButton(onClick = { showExportImportDialog = false }) { Text("Close") }
            }
        )
    }
}

@Composable
fun IvrNodeCard(
    node: IvrNodeEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isNested = node.parentNodeId != 0L
    val badgeColor = when (node.nodeType.uppercase()) {
        "WELCOME" -> NeonCyan
        "MENU" -> ElectricPurple
        "AI_CONVERSATION" -> CyberPink
        "TOOL" -> CyberGreen
        "END_CALL" -> CyberRed
        else -> CyberAmber
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = if (isNested) 24.dp else 0.dp)
            .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onEdit),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (node.dtmfKey.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(NeonCyan.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = node.dtmfKey,
                                fontWeight = FontWeight.Bold,
                                color = NeonCyan,
                                fontSize = 13.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    Text(
                        text = node.title,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimary
                    )
                }

                Surface(
                    color = badgeColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = node.nodeType,
                        color = badgeColor,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        ),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "«${node.messagePrompt}»",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 2
            )

            if (node.speechKeywords.isNotBlank() || node.toolName.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (node.speechKeywords.isNotBlank()) {
                        Text(
                            text = "Voice: ${node.speechKeywords}",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = TextMuted
                        )
                    }
                    if (node.toolName.isNotBlank()) {
                        Text(
                            text = "Tool: ${node.toolName}",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = CyberGreen),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = TextSecondary, modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CyberRed.copy(alpha = 0.8f), modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun NodeEditorDialog(
    node: IvrNodeEntity?,
    existingNodes: List<IvrNodeEntity>,
    aiProfiles: List<AIProfileEntity>,
    onDismiss: () -> Unit,
    onSave: (IvrNodeEntity) -> Unit
) {
    var title by remember { mutableStateOf(node?.title ?: "") }
    var prompt by remember { mutableStateOf(node?.messagePrompt ?: "") }
    var dtmfKey by remember { mutableStateOf(node?.dtmfKey ?: "") }
    var speechKeywords by remember { mutableStateOf(node?.speechKeywords ?: "") }
    var nodeType by remember { mutableStateOf(node?.nodeType ?: "MENU") }
    var parentNodeId by remember { mutableStateOf(node?.parentNodeId ?: 0L) }
    var selectedProfileId by remember { mutableStateOf(node?.aiProfileId ?: 1L) }
    var toolName by remember { mutableStateOf(node?.toolName ?: "") }

    val nodeTypes = listOf("WELCOME", "MENU", "AI_CONVERSATION", "TOOL", "MESSAGE", "END_CALL")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (node == null) "Create Call Flow Node" else "Edit Node") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Node Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    label = { Text("Spoken Prompt / Welcome Text") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = dtmfKey,
                        onValueChange = { dtmfKey = it },
                        label = { Text("DTMF (1,2..)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = speechKeywords,
                        onValueChange = { speechKeywords = it },
                        label = { Text("Voice Keywords") },
                        singleLine = true,
                        modifier = Modifier.weight(2f)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text("Node Type:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    nodeTypes.take(3).forEach { t ->
                        FilterChip(
                            selected = nodeType == t,
                            onClick = { nodeType = t },
                            label = { Text(t, fontSize = 10.sp) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    nodeTypes.drop(3).forEach { t ->
                        FilterChip(
                            selected = nodeType == t,
                            onClick = { nodeType = t },
                            label = { Text(t, fontSize = 10.sp) }
                        )
                    }
                }

                if (nodeType == "TOOL") {
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = toolName,
                        onValueChange = { toolName = it },
                        label = { Text("Tool (e.g. get_ram, get_storage)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalNode = node?.copy(
                        title = title,
                        messagePrompt = prompt,
                        dtmfKey = dtmfKey,
                        speechKeywords = speechKeywords,
                        nodeType = nodeType,
                        parentNodeId = parentNodeId,
                        aiProfileId = selectedProfileId,
                        toolName = toolName
                    ) ?: IvrNodeEntity(
                        id = System.currentTimeMillis(),
                        flowId = 1,
                        title = title.ifBlank { "Menu Branch" },
                        messagePrompt = prompt.ifBlank { "You selected this branch." },
                        dtmfKey = dtmfKey,
                        speechKeywords = speechKeywords,
                        nodeType = nodeType,
                        parentNodeId = parentNodeId,
                        aiProfileId = selectedProfileId,
                        toolName = toolName
                    )
                    onSave(finalNode)
                }
            ) { Text("Save Node") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
