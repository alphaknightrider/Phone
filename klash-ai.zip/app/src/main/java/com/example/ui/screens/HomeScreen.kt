package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    phoneNumber: String,
    onPhoneNumberChange: (String) -> Unit,
    callCount: Int,
    commandCount: Int,
    onNavigate: (String) -> Unit
) {
    val scrollState = rememberScrollState()
    var showEditPhoneDialog by remember { mutableStateOf(false) }
    var tempPhone by remember { mutableStateOf(phoneNumber) }

    // Pulsing animation for the "Agent Ready" beacon
    val infiniteTransition = rememberInfiniteTransition(label = "beacon")
    val alphaAnim by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Cyberpunk HUD Header
        Text(
            text = "KLASH AI",
            style = MaterialTheme.typography.headlineLarge.copy(
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 4.sp,
                fontFamily = FontFamily.Monospace,
                brush = Brush.horizontalGradient(listOf(NeonCyan, ElectricPurple))
            ),
            modifier = Modifier.testTag("app_title")
        )
        Text(
            text = "PROGRAMMABLE AI PHONE AGENT",
            style = MaterialTheme.typography.labelMedium.copy(
                letterSpacing = 2.sp,
                color = TextSecondary,
                fontWeight = FontWeight.Bold
            )
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Agent Status Beacon Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Brush.horizontalGradient(listOf(NeonCyan.copy(alpha = 0.6f), ElectricPurple.copy(alpha = 0.6f))), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(CyberGreen.copy(alpha = alphaAnim))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "● AGENT READY",
                        color = CyberGreen,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Configured Phone Number",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable {
                            tempPhone = phoneNumber
                            showEditPhoneDialog = true
                        }
                        .padding(vertical = 4.dp, horizontal = 8.dp)
                ) {
                    Text(
                        text = phoneNumber.ifBlank { "+91 98765 43210" },
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = NeonCyan
                        ),
                        modifier = Modifier.testTag("configured_phone_text")
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit Number",
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = DarkBorder, thickness = 1.dp)
                Spacer(modifier = Modifier.height(16.dp))

                // Stats Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    StatMetric(label = "Calls Handled", value = "$callCount")
                    VerticalDivider(modifier = Modifier.height(36.dp), color = DarkBorder)
                    StatMetric(label = "AI Commands", value = "$commandCount")
                    VerticalDivider(modifier = Modifier.height(36.dp), color = DarkBorder)
                    StatMetric(label = "Engine Mode", value = "Hybrid")
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Test Call Primary Action
        Button(
            onClick = { onNavigate("test_call") },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("test_ai_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = NeonCyan,
                contentColor = Color(0xFF001F29)
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "🎙 TEST AI (VOICE CALL MODE)",
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                fontSize = 15.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedButton(
            onClick = { onNavigate("ivr_simulator") },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("test_ivr_button"),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = NeonCyan
            ),
            border = ButtonDefaults.outlinedButtonBorder.copy(
                brush = Brush.horizontalGradient(listOf(NeonCyan, ElectricPurple))
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Dialpad, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "📞 TEST IVR KEYPAD SIMULATOR",
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Navigation Grid (Call Flows, AI Profiles, Commands, Tools, Memory, History, Settings)
        Text(
            text = "AGENT ARCHITECTURE",
            style = MaterialTheme.typography.labelSmall.copy(
                letterSpacing = 2.sp,
                color = TextSecondary,
                fontWeight = FontWeight.Bold
            ),
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth()) {
            NavCard(
                title = "Call Flows",
                subtitle = "Visual IVR & DTMF Menu",
                icon = Icons.Default.AccountTree,
                color = NeonCyan,
                modifier = Modifier.weight(1f)
            ) { onNavigate("call_flows") }

            Spacer(modifier = Modifier.width(10.dp))

            NavCard(
                title = "AI Profiles",
                subtitle = "Personas per IVR branch",
                icon = Icons.Default.Psychology,
                color = ElectricPurple,
                modifier = Modifier.weight(1f)
            ) { onNavigate("ai_profiles") }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth()) {
            NavCard(
                title = "Commands",
                subtitle = "Custom Talking Actions",
                icon = Icons.Default.RecordVoiceOver,
                color = CyberPink,
                modifier = Modifier.weight(1f)
            ) { onNavigate("commands") }

            Spacer(modifier = Modifier.width(10.dp))

            NavCard(
                title = "Phone Tools",
                subtitle = "RAM, Storage, Integrations",
                icon = Icons.Default.Build,
                color = CyberGreen,
                modifier = Modifier.weight(1f)
            ) { onNavigate("tools") }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth()) {
            NavCard(
                title = "Memory",
                subtitle = "Long-Term Knowledge",
                icon = Icons.Default.Memory,
                color = CyberAmber,
                modifier = Modifier.weight(1f)
            ) { onNavigate("memory") }

            Spacer(modifier = Modifier.width(10.dp))

            NavCard(
                title = "Call Logs",
                subtitle = "History & Transcripts",
                icon = Icons.Default.History,
                color = TextSecondary,
                modifier = Modifier.weight(1f)
            ) { onNavigate("history") }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth()) {
            NavCard(
                title = "Debug Console",
                subtitle = "Live Execution & Traces",
                icon = Icons.Default.Terminal,
                color = NeonCyanDark,
                modifier = Modifier.weight(1f)
            ) { onNavigate("debug") }

            Spacer(modifier = Modifier.width(10.dp))

            NavCard(
                title = "Settings",
                subtitle = "Security PIN & Telephony",
                icon = Icons.Default.Settings,
                color = TextPrimary,
                modifier = Modifier.weight(1f)
            ) { onNavigate("settings") }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    if (showEditPhoneDialog) {
        AlertDialog(
            onDismissRequest = { showEditPhoneDialog = false },
            title = { Text("Configure Agent Phone Number") },
            text = {
                Column {
                    Text("Enter the incoming phone number (Carrier SIM, SIP, or VoIP line) for this Klash AI agent:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = tempPhone,
                        onValueChange = { tempPhone = it },
                        singleLine = true,
                        placeholder = { Text("+1 (555) 019-2834") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    onPhoneNumberChange(tempPhone)
                    showEditPhoneDialog = false
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showEditPhoneDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun StatMetric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TextPrimary
            )
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted
        )
    }
}

@Composable
fun NavCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(96.dp)
            .clickable(onClick = onClick)
            .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = TextPrimary
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = TextMuted,
                    maxLines = 1
                )
            }
            Icon(
                Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
