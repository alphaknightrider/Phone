package com.example

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.agent.AgentCore
import com.example.database.IvrNodeEntity
import com.example.database.MemoryEntity
import com.example.ui.screens.*
import com.example.ui.theme.KlashAITheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray

class MainActivity : ComponentActivity() {
    private lateinit var agentCore: AgentCore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as KlashApplication
        agentCore = AgentCore(this, app.toolRegistry)

        setContent {
            KlashAITheme {
                val navController = rememberNavController()
                val scope = rememberCoroutineScope()
                val db = app.database

                // SharedPreferences for configured phone number
                val prefs = remember { getSharedPreferences("klash_ui_prefs", Context.MODE_PRIVATE) }
                var phoneNumber by remember {
                    mutableStateOf(prefs.getString("agent_phone_number", "+1 (555) 234-KLASH") ?: "+1 (555) 234-KLASH")
                }

                // Database StateFlow collections
                val callCount by db.callLogDao().getCallCount().collectAsState(initial = 0)
                val commandCount by db.talkingCommandDao().getActiveCommandCount().collectAsState(initial = 3)
                val callLogs by db.callLogDao().getAllLogs().collectAsState(initial = emptyList())
                val aiProfiles by db.aiProfileDao().getAllProfiles().collectAsState(initial = emptyList())
                val callFlows by db.callFlowDao().getAllFlows().collectAsState(initial = emptyList())
                val activeFlow = callFlows.firstOrNull()
                val ivrNodes by db.ivrNodeDao().getNodesForFlow(activeFlow?.id ?: 1L).collectAsState(initial = emptyList())
                val talkingCommands by db.talkingCommandDao().getAllCommands().collectAsState(initial = emptyList())
                val memories by db.memoryDao().getAllMemories().collectAsState(initial = emptyList())
                val toolExecutions by db.toolExecutionDao().getRecentExecutions().collectAsState(initial = emptyList())

                Scaffold(modifier = Modifier.fillMaxSize()) { _ ->
                    NavHost(navController = navController, startDestination = "home") {
                        composable("home") {
                            HomeScreen(
                                phoneNumber = phoneNumber,
                                onPhoneNumberChange = { newNum ->
                                    phoneNumber = newNum
                                    prefs.edit().putString("agent_phone_number", newNum).apply()
                                },
                                callCount = callCount,
                                commandCount = commandCount,
                                onNavigate = { route -> navController.navigate(route) }
                            )
                        }

                        composable("call_flows") {
                            CallFlowBuilderScreen(
                                flows = callFlows,
                                activeFlow = activeFlow,
                                nodes = ivrNodes,
                                aiProfiles = aiProfiles,
                                onSelectFlow = { /* Flow selection */ },
                                onSaveNode = { node ->
                                    scope.launch(Dispatchers.IO) {
                                        db.ivrNodeDao().insertNode(node)
                                    }
                                },
                                onDeleteNode = { nodeId ->
                                    scope.launch(Dispatchers.IO) {
                                        db.ivrNodeDao().deleteNode(nodeId)
                                    }
                                },
                                onImportFlowJson = { jsonStr ->
                                    scope.launch(Dispatchers.IO) {
                                        try {
                                            val arr = JSONArray(jsonStr)
                                            val list = mutableListOf<IvrNodeEntity>()
                                            for (i in 0 until arr.length()) {
                                                val obj = arr.getJSONObject(i)
                                                list.add(
                                                    IvrNodeEntity(
                                                        id = obj.optLong("id", System.currentTimeMillis() + i),
                                                        flowId = activeFlow?.id ?: 1L,
                                                        nodeType = obj.optString("nodeType", "MENU"),
                                                        title = obj.optString("title", "Branch"),
                                                        messagePrompt = obj.optString("messagePrompt", ""),
                                                        dtmfKey = obj.optString("dtmfKey", ""),
                                                        speechKeywords = obj.optString("speechKeywords", ""),
                                                        parentNodeId = obj.optLong("parentNodeId", 0L),
                                                        aiProfileId = obj.optLong("aiProfileId", 1L),
                                                        toolName = obj.optString("toolName", "")
                                                    )
                                                )
                                            }
                                            if (list.isNotEmpty()) {
                                                db.ivrNodeDao().insertNodes(list)
                                            }
                                        } catch (_: Exception) {}
                                    }
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("ai_profiles") {
                            AiProfilesScreen(
                                profiles = aiProfiles,
                                onSaveProfile = { profile ->
                                    scope.launch(Dispatchers.IO) {
                                        db.aiProfileDao().insertProfile(profile)
                                    }
                                },
                                onDeleteProfile = { id ->
                                    scope.launch(Dispatchers.IO) {
                                        db.aiProfileDao().deleteProfile(id)
                                    }
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("commands") {
                            TalkingCommandsScreen(
                                commands = talkingCommands,
                                onSaveCommand = { cmd ->
                                    scope.launch(Dispatchers.IO) {
                                        db.talkingCommandDao().insertCommand(cmd)
                                    }
                                },
                                onDeleteCommand = { id ->
                                    scope.launch(Dispatchers.IO) {
                                        db.talkingCommandDao().deleteCommand(id)
                                    }
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("tools") {
                            ToolsAndIntegrationsScreen(
                                toolRegistry = app.toolRegistry,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("test_call") {
                            TestCallScreen(
                                agentCore = agentCore,
                                configuredPhoneNumber = phoneNumber,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("ivr_simulator") {
                            IvrSimulatorScreen(
                                agentCore = agentCore,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("memory") {
                            MemoryScreen(
                                memories = memories,
                                onAddMemory = { cat, key, value ->
                                    scope.launch(Dispatchers.IO) {
                                        db.memoryDao().insertMemory(
                                            MemoryEntity(
                                                category = cat,
                                                memoryKey = key,
                                                memoryValue = value
                                            )
                                        )
                                    }
                                },
                                onDeleteMemory = { id ->
                                    scope.launch(Dispatchers.IO) {
                                        db.memoryDao().deleteMemory(id)
                                    }
                                },
                                onClearAll = {
                                    scope.launch(Dispatchers.IO) {
                                        db.memoryDao().clearAll()
                                    }
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("history") {
                            CallHistoryScreen(
                                callLogs = callLogs,
                                onDeleteLog = { id ->
                                    scope.launch(Dispatchers.IO) {
                                        db.callLogDao().deleteLog(id)
                                    }
                                },
                                onClearAll = {
                                    scope.launch(Dispatchers.IO) {
                                        db.callLogDao().clearAll()
                                    }
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("debug") {
                            DebugConsoleScreen(
                                executions = toolExecutions,
                                onClearLogs = {
                                    scope.launch(Dispatchers.IO) {
                                        db.toolExecutionDao().clearHistory()
                                    }
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("settings") {
                            SettingsScreen(
                                currentProvider = agentCore.aiProvider,
                                onSelectProvider = { provider ->
                                    agentCore.aiProvider = provider
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        agentCore.cleanup()
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    androidx.compose.material3.Text(text = "Hello $name!", modifier = modifier)
}

