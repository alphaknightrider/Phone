package com.example.ivr

import com.example.database.CallFlowEntity
import com.example.database.IvrNodeEntity
import com.example.tools.ToolRegistry

sealed class IvrEvent {
    data class SpokenPrompt(val text: String, val node: IvrNodeEntity) : IvrEvent()
    data class AiModeActivated(val profileId: Long, val prompt: String) : IvrEvent()
    data class ToolTriggered(val toolName: String, val resultSummary: String) : IvrEvent()
    data class InvalidInput(val attemptsRemaining: Int) : IvrEvent()
    object CallEnded : IvrEvent()
}

class CallFlowEngine(
    private val toolRegistry: ToolRegistry
) {
    private var allNodes: List<IvrNodeEntity> = emptyList()
    var currentNode: IvrNodeEntity? = null
        private set
    private val nodeHistory = mutableListOf<IvrNodeEntity>()
    var invalidAttempts = 0
        private set
    val maxRetries = 3

    fun initFlow(nodes: List<IvrNodeEntity>, startNodeId: Long = 100): IvrEvent? {
        this.allNodes = nodes
        this.nodeHistory.clear()
        invalidAttempts = 0

        val start = nodes.firstOrNull { it.id == startNodeId } ?: nodes.firstOrNull()
        currentNode = start
        return start?.let { processNode(it) }
    }

    fun handleInput(input: String): IvrEvent {
        val node = currentNode ?: return IvrEvent.CallEnded
        val cleanInput = input.trim().lowercase()

        // Universal Star or "main menu" -> Return to root
        if (cleanInput == "*" || cleanInput == "main menu" || cleanInput == "home") {
            val rootNode = allNodes.firstOrNull { it.parentNodeId == 0L } ?: allNodes.firstOrNull()
            if (rootNode != null) {
                nodeHistory.clear()
                invalidAttempts = 0
                currentNode = rootNode
                return processNode(rootNode)
            }
        }

        // Universal 9 or "goodbye" -> End call if at menu
        if (cleanInput == "9" && node.nodeType != "MENU") {
            return IvrEvent.CallEnded
        }

        // Find child branches belonging to currentNode
        val childNodes = allNodes.filter { it.parentNodeId == node.id }

        // Match by DTMF or speech keywords
        val matchedChild = childNodes.firstOrNull { child ->
            child.dtmfKey.equals(cleanInput, ignoreCase = true) ||
                    (child.speechKeywords.isNotBlank() &&
                            child.speechKeywords.split(",").any { kw ->
                                val trimmed = kw.trim().lowercase()
                                trimmed.isNotBlank() && (cleanInput == trimmed || cleanInput.contains(trimmed))
                            })
        }

        if (matchedChild != null) {
            invalidAttempts = 0
            nodeHistory.add(node)
            currentNode = matchedChild
            return processNode(matchedChild)
        }

        // Invalid input logic
        invalidAttempts++
        val remaining = maxRetries - invalidAttempts
        if (remaining <= 0) {
            return IvrEvent.CallEnded
        }
        return IvrEvent.InvalidInput(remaining)
    }

    private fun processNode(node: IvrNodeEntity): IvrEvent {
        return when (node.nodeType.uppercase()) {
            "WELCOME", "MENU", "MESSAGE" -> {
                IvrEvent.SpokenPrompt(node.messagePrompt, node)
            }
            "AI_CONVERSATION" -> {
                IvrEvent.AiModeActivated(node.aiProfileId, node.messagePrompt)
            }
            "TOOL" -> {
                IvrEvent.ToolTriggered(node.toolName, node.messagePrompt)
            }
            "END_CALL" -> {
                IvrEvent.CallEnded
            }
            else -> {
                IvrEvent.SpokenPrompt(node.messagePrompt, node)
            }
        }
    }

    fun getSubmenuOptions(): List<IvrNodeEntity> {
        val node = currentNode ?: return emptyList()
        return allNodes.filter { it.parentNodeId == node.id }
    }
}
