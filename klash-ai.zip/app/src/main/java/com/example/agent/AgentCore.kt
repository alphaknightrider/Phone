package com.example.agent

import android.content.Context
import com.example.KlashApplication
import com.example.ai.AIProvider
import com.example.ai.GeminiProvider
import com.example.ai.LocalRuleProvider
import com.example.commands.CommandMatcher
import com.example.commands.CommandParser
import com.example.commands.WorkflowEngine
import com.example.database.AIProfileEntity
import com.example.database.CallLogEntity
import com.example.database.CallerProfileEntity
import com.example.ivr.CallFlowEngine
import com.example.ivr.IvrEvent
import com.example.security.RiskLevel
import com.example.tools.ToolRegistry
import com.example.voice.AudioSessionManager
import com.example.voice.SpeechEngine
import com.example.voice.TtsEngine
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class CallState {
    IDLE,
    INCOMING,
    RINGING,
    ANSWERING,
    ACTIVE,
    LISTENING,
    THINKING,
    EXECUTING,
    SPEAKING,
    WAITING,
    DISCONNECTED
}

data class PendingConfirmation(
    val toolName: String,
    val arguments: Map<String, String>,
    val promptText: String
)

class AgentCore(
    private val context: Context,
    private val toolRegistry: ToolRegistry
) {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val database = (context.applicationContext as KlashApplication).database
    private val commandMatcher = CommandMatcher()
    private val workflowEngine = WorkflowEngine(context, toolRegistry)

    val speechEngine = SpeechEngine(context)
    val ttsEngine = TtsEngine(context)
    val audioSessionManager = AudioSessionManager(context)
    val ivrEngine = CallFlowEngine(toolRegistry)

    private val _callState = MutableStateFlow(CallState.IDLE)
    val callState: StateFlow<CallState> = _callState.asStateFlow()

    private val _liveTranscript = MutableStateFlow("")
    val liveTranscript: StateFlow<String> = _liveTranscript.asStateFlow()

    private val _lastAiResponse = MutableStateFlow("")
    val lastAiResponse: StateFlow<String> = _lastAiResponse.asStateFlow()

    private val _activeProfile = MutableStateFlow<AIProfileEntity?>(null)
    val activeProfile: StateFlow<AIProfileEntity?> = _activeProfile.asStateFlow()

    private val _activeCaller = MutableStateFlow<CallerProfileEntity?>(null)
    val activeCaller: StateFlow<CallerProfileEntity?> = _activeCaller.asStateFlow()

    private val conversationHistory = mutableListOf<Pair<String, String>>()
    private val fullTranscriptLog = StringBuilder()
    private val usedCommands = mutableSetOf<String>()
    private val usedTools = mutableSetOf<String>()

    private var currentCallId: Long = System.currentTimeMillis()
    private var callStartTime: Long = 0L
    private var isAiMode = false
    private var pendingConfirmation: PendingConfirmation? = null
    var aiProvider: AIProvider = GeminiProvider()

    fun startCall(
        callerNumber: String = "+15550001234",
        callerName: String = "Test Caller",
        transportMode: String = "TEST_MODE"
    ) {
        scope.launch {
            _callState.value = CallState.ANSWERING
            callStartTime = System.currentTimeMillis()
            currentCallId = callStartTime
            fullTranscriptLog.clear()
            conversationHistory.clear()
            usedCommands.clear()
            usedTools.clear()
            isAiMode = false
            pendingConfirmation = null

            // Audio routing
            audioSessionManager.setupCallAudio(useSpeaker = true)

            // Resolve caller permissions
            val profile = database.callerProfileDao().getProfileForNumber(callerNumber)
                ?: CallerProfileEntity(phoneNumber = callerNumber, callerName = callerName, tier = "GUEST")
            _activeCaller.value = profile

            // Resolve default AI profile
            val defaultAi = database.aiProfileDao().getDefaultProfile()
                ?: database.aiProfileDao().getProfileById(1)
            _activeProfile.value = defaultAi

            // Fetch default IVR nodes
            val defaultFlow = database.callFlowDao().getDefaultFlow()
            val flowId = defaultFlow?.id ?: 1L
            val nodes = database.ivrNodeDao().getNodesListForFlow(flowId)

            _callState.value = CallState.ACTIVE
            val startEvent = ivrEngine.initFlow(nodes, defaultFlow?.startNodeId ?: 100L)
            handleIvrEvent(startEvent)
        }
    }

    fun handleUserInput(input: String) {
        val trimmed = input.trim()
        if (trimmed.isBlank()) return
        _liveTranscript.value = trimmed
        fullTranscriptLog.append("User: $trimmed\n")
        conversationHistory.add("user" to trimmed)

        // Check if there is an active pending confirmation
        val pending = pendingConfirmation
        if (pending != null) {
            val lower = trimmed.lowercase()
            if (lower == "yes" || lower == "1" || lower == "confirm" || lower == "sure") {
                pendingConfirmation = null
                executeConfirmedTool(pending.toolName, pending.arguments)
            } else {
                pendingConfirmation = null
                speakAndThenListen("Action cancelled. How else can I assist you?")
            }
            return
        }

        // Check Talking Commands first (Intent Engine)
        scope.launch {
            val commands = database.talkingCommandDao().getActiveCommands()
            val matchedCmd = commandMatcher.findMatchingCommand(trimmed, commands)

            if (matchedCmd != null) {
                usedCommands.add(matchedCmd.triggerPhrase)
                executeTalkingCommand(matchedCmd)
                return@launch
            }

            // If currently in AI Mode, pass to AI Engine
            if (isAiMode) {
                processWithAi(trimmed)
                return@launch
            }

            // Otherwise, route through IVR / DTMF engine
            val event = ivrEngine.handleInput(trimmed)
            handleIvrEvent(event)
        }
    }

    private fun handleIvrEvent(event: IvrEvent?) {
        when (event) {
            is IvrEvent.SpokenPrompt -> {
                speakAndThenListen(event.text)
            }
            is IvrEvent.AiModeActivated -> {
                isAiMode = true
                scope.launch {
                    val profile = database.aiProfileDao().getProfileById(event.profileId)
                    if (profile != null) _activeProfile.value = profile
                    speakAndThenListen(event.prompt)
                }
            }
            is IvrEvent.ToolTriggered -> {
                scope.launch {
                    executeToolDirectly(event.toolName)
                }
            }
            is IvrEvent.InvalidInput -> {
                val prompt = "Sorry, that was an invalid option. You have ${event.attemptsRemaining} attempts remaining. Please press a valid number or say Main Menu."
                speakAndThenListen(prompt)
            }
            is IvrEvent.CallEnded -> {
                endCall("Call finished.")
            }
            null -> {
                speakAndThenListen("Welcome to Klash AI. How may I assist you?")
            }
        }
    }

    private suspend fun executeTalkingCommand(command: com.example.database.TalkingCommandEntity) {
        _callState.value = CallState.EXECUTING
        val actions = CommandParser.parseActions(command.actionsJson)
        val callerTier = _activeCaller.value?.tier ?: "OWNER"

        val variables = mutableMapOf(
            "caller_number" to (_activeCaller.value?.phoneNumber ?: ""),
            "caller_name" to (_activeCaller.value?.callerName ?: "")
        )

        val result = workflowEngine.executeActions(actions, variables, currentCallId, callerTier)
        usedTools.addAll(result.executedTools)

        if (result.endCallRequested) {
            endCall(result.finalSummary)
        } else {
            speakAndThenListen(result.finalSummary)
        }
    }

    private suspend fun processWithAi(userInput: String) {
        _callState.value = CallState.THINKING
        val profile = _activeProfile.value ?: database.aiProfileDao().getProfileById(1)
        val instructions = profile?.instructions ?: "You are an AI phone assistant."
        val allowedTools = profile?.allowedTools?.split(",")?.map { it.trim() } ?: listOf("get_ram", "get_storage", "get_battery")

        val response = aiProvider.generateResponse(
            systemInstruction = instructions,
            history = conversationHistory,
            userMessage = userInput,
            allowedTools = allowedTools
        )

        if (response.toolCall != null) {
            val toolName = response.toolCall.toolName
            if (toolName.equals("end_call", ignoreCase = true)) {
                endCall(response.spokenText)
                return
            }

            // Check if confirmation needed
            val risk = toolRegistry.getTool(toolName)?.riskLevel ?: RiskLevel.LOW
            if (risk == RiskLevel.HIGH || (risk == RiskLevel.MEDIUM && toolName.contains("restart"))) {
                pendingConfirmation = PendingConfirmation(toolName, response.toolCall.arguments, response.spokenText)
                speakAndThenListen("Warning: Executing $toolName is a high impact action. Are you sure you want to proceed? Press 1 or say yes to confirm.")
                return
            }

            executeToolDirectly(toolName, response.toolCall.arguments)
        } else {
            _lastAiResponse.value = response.spokenText
            fullTranscriptLog.append("Klash: ${response.spokenText}\n")
            conversationHistory.add("model" to response.spokenText)
            speakAndThenListen(response.spokenText)
        }
    }

    private suspend fun executeToolDirectly(toolName: String, args: Map<String, String> = emptyMap()) {
        _callState.value = CallState.EXECUTING
        val callerTier = _activeCaller.value?.tier ?: "OWNER"
        val toolResult = toolRegistry.executeTool(toolName, args, currentCallId, callerTier)
        usedTools.add(toolName)

        _lastAiResponse.value = toolResult.spokenSummary
        fullTranscriptLog.append("Tool ($toolName): ${toolResult.spokenSummary}\n")
        conversationHistory.add("model" to toolResult.spokenSummary)

        speakAndThenListen(toolResult.spokenSummary)
    }

    private fun executeConfirmedTool(toolName: String, args: Map<String, String>) {
        scope.launch {
            executeToolDirectly(toolName, args)
        }
    }

    fun speakAndThenListen(text: String) {
        _callState.value = CallState.SPEAKING
        val profile = _activeProfile.value

        ttsEngine.speak(
            text = text,
            speechRate = profile?.speechRate ?: 1.0f,
            speechPitch = profile?.speechPitch ?: 1.0f,
            language = profile?.language ?: "en-US",
            onComplete = {
                if (_callState.value == CallState.SPEAKING) {
                    startListeningCycle()
                }
            }
        )
    }

    private fun startListeningCycle() {
        _callState.value = CallState.LISTENING
        val lang = _activeProfile.value?.language ?: "en-US"

        speechEngine.startListening(
            language = lang,
            onBargeIn = {
                // Interruption/barge-in detected: stop speech immediately
                ttsEngine.stop()
            },
            onResult = { spoken ->
                handleUserInput(spoken)
            }
        )
    }

    fun endCall(closingText: String = "Call ended.") {
        _callState.value = CallState.DISCONNECTED
        speechEngine.stopListening()

        ttsEngine.speak(closingText, onComplete = {
            audioSessionManager.resetAudio()
            _callState.value = CallState.IDLE
        })

        // Persist call log in Room database
        scope.launch(Dispatchers.IO) {
            val duration = ((System.currentTimeMillis() - callStartTime) / 1000).toInt().coerceAtLeast(1)
            database.callLogDao().insertLog(
                CallLogEntity(
                    callerNumber = _activeCaller.value?.phoneNumber ?: "Test Simulator",
                    callerName = _activeCaller.value?.callerName ?: "Owner",
                    startTime = callStartTime,
                    durationSeconds = duration,
                    callFlowName = "Main Call Flow",
                    aiProfileName = _activeProfile.value?.name ?: "Klash",
                    commandsUsed = usedCommands.joinToString(", "),
                    toolsUsed = usedTools.joinToString(", "),
                    transcript = fullTranscriptLog.toString(),
                    state = "COMPLETED",
                    transportMode = "VOIP_MEDIA"
                )
            )
        }
    }

    fun cleanup() {
        speechEngine.destroy()
        ttsEngine.shutdown()
        audioSessionManager.resetAudio()
        scope.cancel()
    }
}
