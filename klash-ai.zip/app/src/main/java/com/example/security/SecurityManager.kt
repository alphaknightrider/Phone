package com.example.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

enum class RiskLevel {
    LOW,
    MEDIUM,
    HIGH
}

class SecurityManager(private val context: Context) {
    private val keyAlias = "KlashMasterKey"
    private val keyStore: KeyStore? = try {
        KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    } catch (_: Exception) {
        null
    }
    private val prefs = context.getSharedPreferences("klash_secure_prefs", Context.MODE_PRIVATE)

    init {
        ensureMasterKey()
    }

    private fun ensureMasterKey() {
        val ks = keyStore ?: return
        try {
            if (!ks.containsAlias(keyAlias)) {
                val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
                keyGenerator.init(
                    KeyGenParameterSpec.Builder(
                        keyAlias,
                        KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                    )
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(256)
                        .build()
                )
                keyGenerator.generateKey()
            }
        } catch (_: Exception) {}
    }

    private fun getSecretKey(): SecretKey? {
        return try {
            keyStore?.getKey(keyAlias, null) as? SecretKey
        } catch (_: Exception) {
            null
        }
    }

    fun encryptString(plainText: String): String {
        if (plainText.isEmpty()) return ""
        val secretKey = getSecretKey()
        if (secretKey == null) {
            return Base64.encodeToString(plainText.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        }
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, secretKey)
            val iv = cipher.iv
            val cipherText = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
            val combined = ByteArray(iv.size + cipherText.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(cipherText, 0, combined, iv.size, cipherText.size)
            Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (e: Exception) {
            Base64.encodeToString(plainText.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        }
    }

    fun decryptString(encryptedBase64: String): String {
        if (encryptedBase64.isEmpty()) return ""
        val secretKey = getSecretKey()
        if (secretKey == null) {
            return try {
                String(Base64.decode(encryptedBase64, Base64.NO_WRAP), Charsets.UTF_8)
            } catch (_: Exception) {
                ""
            }
        }
        return try {
            val combined = Base64.decode(encryptedBase64, Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val iv = combined.copyOfRange(0, 12)
            val cipherText = combined.copyOfRange(12, combined.size)
            val spec = GCMParameterSpec(128, iv)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)
            String(cipher.doFinal(cipherText), Charsets.UTF_8)
        } catch (e: Exception) {
            try {
                String(Base64.decode(encryptedBase64, Base64.NO_WRAP), Charsets.UTF_8)
            } catch (ex: Exception) {
                ""
            }
        }
    }

    fun saveEncryptedSecret(key: String, secretValue: String) {
        val encrypted = encryptString(secretValue)
        prefs.edit().putString(key, encrypted).apply()
    }

    fun getEncryptedSecret(key: String): String {
        val encrypted = prefs.getString(key, null) ?: return ""
        return decryptString(encrypted)
    }

    // Owner PIN Protection
    fun isOwnerPinSet(): Boolean {
        return prefs.contains("owner_pin_hash")
    }

    fun setOwnerPin(pin: String) {
        val hash = sha256(pin)
        prefs.edit().putString("owner_pin_hash", hash).apply()
    }

    fun verifyOwnerPin(pin: String): Boolean {
        val savedHash = prefs.getString("owner_pin_hash", null)
        if (savedHash == null) return true // Default unlocked if not yet set
        return savedHash == sha256(pin)
    }

    fun getRiskLevelForTool(toolName: String): RiskLevel {
        return when (toolName.lowercase()) {
            "get_ram", "get_storage", "get_battery", "get_network", "get_device_info", "web_search", "server_status", "player_count" -> RiskLevel.LOW
            "create_file", "create_folder", "read_permitted_file", "send_message", "server_restart", "launch_browser", "open_app" -> RiskLevel.MEDIUM
            "delete_file", "server_stop", "send_announcement", "modify_system_setting" -> RiskLevel.HIGH
            else -> RiskLevel.MEDIUM
        }
    }

    private fun sha256(input: String): String {
        val bytes = java.security.MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
