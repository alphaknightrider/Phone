package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "call_logs")
data class CallLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val callerNumber: String,
    val callerName: String = "Unknown",
    val startTime: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 0,
    val callFlowName: String = "Default Flow",
    val aiProfileName: String = "General Assistant",
    val commandsUsed: String = "", // Comma-separated
    val toolsUsed: String = "", // Comma-separated
    val transcript: String = "",
    val state: String = "COMPLETED",
    val transportMode: String = "VOIP_MEDIA" // "VOIP_MEDIA" or "SIM_TELECOM" or "TEST_MODE"
)

@Entity(tableName = "ai_profiles")
data class AIProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val personality: String = "Professional, helpful, and concise",
    val instructions: String = "You are a personal phone assistant. Answer clearly and concisely.",
    val voiceName: String = "Default",
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val language: String = "en-US", // "en-US", "hi-IN", "hi-Latn"
    val allowedTools: String = "get_ram,get_storage,get_battery,get_network,get_device_info", // Comma-separated
    val responseLength: String = "SHORT", // "SHORT", "BALANCED", "DETAILED"
    val isDefault: Boolean = false
)

@Entity(tableName = "call_flows")
data class CallFlowEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val description: String = "",
    val startNodeId: Long = 1,
    val isDefault: Boolean = false,
    val language: String = "en-US",
    val retryCount: Int = 3,
    val timeoutSeconds: Int = 10,
    val jsonFlowData: String = ""
)

@Entity(tableName = "ivr_nodes")
data class IvrNodeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val flowId: Long = 1,
    val nodeType: String, // "WELCOME", "MENU", "AI_CONVERSATION", "TOOL", "MESSAGE", "CONDITION", "END_CALL"
    val title: String,
    val messagePrompt: String,
    val dtmfKey: String = "", // "1", "2", "3", "*", "#", etc.
    val speechKeywords: String = "", // e.g. "ai assistant, help, status"
    val parentNodeId: Long = 0,
    val targetNodeId: Long = 0,
    val aiProfileId: Long = 1,
    val toolName: String = "",
    val toolArgsJson: String = "{}",
    val conditionExpr: String = "", // e.g. "battery < 20"
    val orderIndex: Int = 0
)

@Entity(tableName = "talking_commands")
data class TalkingCommandEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val triggerPhrase: String,
    val aliases: String = "", // Comma-separated alternative phrases
    val matchingMode: String = "BOTH", // "EXACT", "AI", "BOTH"
    val actionsJson: String = "[]", // Serialized list of CommandAction
    val confirmationPolicy: String = "NOT_REQUIRED", // "NOT_REQUIRED", "ASK_CONFIRMATION", "STRONG_CONFIRMATION"
    val isEnabled: Boolean = true,
    val description: String = ""
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String = "GENERAL", // "GENERAL", "SERVER", "PREFERENCE", "CONTACT"
    val memoryKey: String,
    val memoryValue: String,
    val timestamp: Long = System.currentTimeMillis(),
    val aiProfileId: Long = 0 // 0 = global
)

@Entity(tableName = "tool_executions")
data class ToolExecutionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val callId: Long = 0,
    val toolName: String,
    val argumentsJson: String,
    val resultSummary: String,
    val status: String = "SUCCESS", // "SUCCESS", "FAILED", "CONFIRMATION_REJECTED"
    val timestamp: Long = System.currentTimeMillis(),
    val riskLevel: String = "LOW" // "LOW", "MEDIUM", "HIGH"
)

@Entity(tableName = "caller_profiles")
data class CallerProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val phoneNumber: String,
    val callerName: String,
    val tier: String = "GUEST", // "OWNER", "TRUSTED", "GUEST", "BLOCKED"
    val allowedAiProfiles: String = "*", // "*" or comma-separated profile IDs
    val allowedCommands: String = "*",
    val allowedTools: String = "get_ram,get_storage,get_battery",
    val maxCallDurationSeconds: Int = 300,
    val notes: String = ""
)

@Entity(tableName = "integrations")
data class IntegrationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val integrationType: String, // "PTERODACTYL", "DISCORD", "WEB_SEARCH", "SIP_VOIP"
    val name: String,
    val endpointUrl: String = "",
    val isEnabled: Boolean = false,
    val extraConfigJson: String = "{}"
)

@Entity(tableName = "scheduled_tasks")
data class ScheduledTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val cronSchedule: String = "0 8 * * *", // e.g. Daily at 8:00 AM
    val commandTrigger: String = "Check my phone",
    val isEnabled: Boolean = true,
    val lastRunTimestamp: Long = 0L,
    val notifySpoken: Boolean = true
)
