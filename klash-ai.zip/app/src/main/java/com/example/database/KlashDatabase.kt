package com.example.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        CallLogEntity::class,
        AIProfileEntity::class,
        CallFlowEntity::class,
        IvrNodeEntity::class,
        TalkingCommandEntity::class,
        MemoryEntity::class,
        ToolExecutionEntity::class,
        CallerProfileEntity::class,
        IntegrationEntity::class,
        ScheduledTaskEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class KlashDatabase : RoomDatabase() {
    abstract fun callLogDao(): CallLogDao
    abstract fun aiProfileDao(): AIProfileDao
    abstract fun callFlowDao(): CallFlowDao
    abstract fun ivrNodeDao(): IvrNodeDao
    abstract fun talkingCommandDao(): TalkingCommandDao
    abstract fun memoryDao(): MemoryDao
    abstract fun toolExecutionDao(): ToolExecutionDao
    abstract fun callerProfileDao(): CallerProfileDao
    abstract fun integrationDao(): IntegrationDao
    abstract fun scheduledTaskDao(): ScheduledTaskDao

    companion object {
        @Volatile
        private var INSTANCE: KlashDatabase? = null

        fun getInstance(context: Context): KlashDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KlashDatabase::class.java,
                    "klash_ai.db"
                )
                    .addCallback(DatabaseCallback())
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                CoroutineScope(Dispatchers.IO).launch {
                    val instance = INSTANCE ?: return@launch
                    populateInitialData(instance)
                }
            }
        }

        suspend fun populateInitialData(db: KlashDatabase) {
            // 1. Initial AI Personas
            val generalProfileId = db.aiProfileDao().insertProfile(
                AIProfileEntity(
                    id = 1,
                    name = "Klash",
                    personality = "Professional, witty, and concise",
                    instructions = "You are the personal AI phone assistant of the owner. Keep spoken answers under 2 sentences unless asked for details.",
                    voiceName = "System voice",
                    speechRate = 1.0f,
                    speechPitch = 1.0f,
                    language = "en-US",
                    allowedTools = "get_ram,get_storage,get_battery,get_network,get_device_info,web_search",
                    responseLength = "SHORT",
                    isDefault = true
                )
            )

            db.aiProfileDao().insertProfile(
                AIProfileEntity(
                    id = 2,
                    name = "Tech Support AI",
                    personality = "Diagnostic, technical, direct, and structured",
                    instructions = "You diagnose hardware, RAM, storage, and device telemetry. Report raw numbers and status cleanly.",
                    voiceName = "System voice",
                    speechRate = 1.05f,
                    speechPitch = 0.95f,
                    language = "en-US",
                    allowedTools = "get_ram,get_storage,get_battery,get_network,get_device_info,list_permitted_files",
                    responseLength = "BALANCED",
                    isDefault = false
                )
            )

            db.aiProfileDao().insertProfile(
                AIProfileEntity(
                    id = 3,
                    name = "Minecraft AI",
                    personality = "Gamer, energetic, and knowledgeable about Minecraft server hosting",
                    instructions = "You monitor the Minecraft server, TPS, online players, and paper releases.",
                    voiceName = "System voice",
                    speechRate = 1.0f,
                    speechPitch = 1.1f,
                    language = "en-US",
                    allowedTools = "server_status,player_count,server_restart,web_search",
                    responseLength = "SHORT",
                    isDefault = false
                )
            )

            // 2. Initial Call Flow
            val flowId = db.callFlowDao().insertFlow(
                CallFlowEntity(
                    id = 1,
                    name = "Main Call Flow",
                    description = "Default phone IVR with 5 menu branches and nested hardware submenus",
                    startNodeId = 100,
                    isDefault = true,
                    language = "en-US",
                    retryCount = 3,
                    timeoutSeconds = 10,
                    jsonFlowData = ""
                )
            )

            // 3. Initial IVR Nodes
            // Root Welcome
            db.ivrNodeDao().insertNode(
                IvrNodeEntity(
                    id = 100,
                    flowId = flowId,
                    nodeType = "WELCOME",
                    title = "Welcome Greeting",
                    messagePrompt = "Welcome to Klash AI, your programmable personal phone agent. Press 1 for AI Assistant. Press 2 for phone information. Press 3 for Minecraft server. Press 4 for custom AI. Press 5 for help.",
                    dtmfKey = "",
                    speechKeywords = "",
                    parentNodeId = 0,
                    targetNodeId = 101,
                    orderIndex = 0
                )
            )

            // Press 1 -> AI Assistant
            db.ivrNodeDao().insertNode(
                IvrNodeEntity(
                    id = 101,
                    flowId = flowId,
                    nodeType = "AI_CONVERSATION",
                    title = "AI Assistant Branch",
                    messagePrompt = "AI Assistant activated. How may I assist you today? You can speak naturally.",
                    dtmfKey = "1",
                    speechKeywords = "ai, assistant, klash, talk",
                    parentNodeId = 100,
                    targetNodeId = 0,
                    aiProfileId = 1,
                    orderIndex = 1
                )
            )

            // Press 2 -> Phone Information Menu (Nested IVR)
            db.ivrNodeDao().insertNode(
                IvrNodeEntity(
                    id = 102,
                    flowId = flowId,
                    nodeType = "MENU",
                    title = "Phone Info Submenu",
                    messagePrompt = "Phone Information menu. Press 1 for RAM. Press 2 for Storage. Press 3 for Battery. Press 4 for Network. Press 9 for Main Menu.",
                    dtmfKey = "2",
                    speechKeywords = "phone, device, info, hardware",
                    parentNodeId = 100,
                    targetNodeId = 0,
                    orderIndex = 2
                )
            )

            // Submenu options under 102
            db.ivrNodeDao().insertNode(
                IvrNodeEntity(
                    id = 201,
                    flowId = flowId,
                    nodeType = "TOOL",
                    title = "Check RAM",
                    messagePrompt = "Checking device memory...",
                    dtmfKey = "1",
                    speechKeywords = "ram, memory",
                    parentNodeId = 102,
                    targetNodeId = 102,
                    toolName = "get_ram",
                    orderIndex = 0
                )
            )
            db.ivrNodeDao().insertNode(
                IvrNodeEntity(
                    id = 202,
                    flowId = flowId,
                    nodeType = "TOOL",
                    title = "Check Storage",
                    messagePrompt = "Checking storage space...",
                    dtmfKey = "2",
                    speechKeywords = "storage, disk, space",
                    parentNodeId = 102,
                    targetNodeId = 102,
                    toolName = "get_storage",
                    orderIndex = 1
                )
            )
            db.ivrNodeDao().insertNode(
                IvrNodeEntity(
                    id = 203,
                    flowId = flowId,
                    nodeType = "TOOL",
                    title = "Check Battery",
                    messagePrompt = "Checking battery level...",
                    dtmfKey = "3",
                    speechKeywords = "battery, power, charge",
                    parentNodeId = 102,
                    targetNodeId = 102,
                    toolName = "get_battery",
                    orderIndex = 2
                )
            )
            db.ivrNodeDao().insertNode(
                IvrNodeEntity(
                    id = 204,
                    flowId = flowId,
                    nodeType = "TOOL",
                    title = "Check Network",
                    messagePrompt = "Checking network connectivity...",
                    dtmfKey = "4",
                    speechKeywords = "network, wifi, cellular, internet",
                    parentNodeId = 102,
                    targetNodeId = 102,
                    toolName = "get_network",
                    orderIndex = 3
                )
            )
            db.ivrNodeDao().insertNode(
                IvrNodeEntity(
                    id = 209,
                    flowId = flowId,
                    nodeType = "WELCOME",
                    title = "Return to Main Menu",
                    messagePrompt = "Returning to main menu.",
                    dtmfKey = "9",
                    speechKeywords = "back, main, home, exit",
                    parentNodeId = 102,
                    targetNodeId = 100,
                    orderIndex = 4
                )
            )

            // Press 3 -> Minecraft
            db.ivrNodeDao().insertNode(
                IvrNodeEntity(
                    id = 103,
                    flowId = flowId,
                    nodeType = "AI_CONVERSATION",
                    title = "Minecraft AI Branch",
                    messagePrompt = "Connected to Minecraft AI. You can say 'Check server status', 'How many players online?', or 'Restart server'.",
                    dtmfKey = "3",
                    speechKeywords = "minecraft, server, players, game",
                    parentNodeId = 100,
                    targetNodeId = 0,
                    aiProfileId = 3,
                    orderIndex = 3
                )
            )

            // Press 4 -> Custom AI
            db.ivrNodeDao().insertNode(
                IvrNodeEntity(
                    id = 104,
                    flowId = flowId,
                    nodeType = "AI_CONVERSATION",
                    title = "Technical Support AI",
                    messagePrompt = "Technical Support AI online. State your hardware or software issue.",
                    dtmfKey = "4",
                    speechKeywords = "custom, tech, support, diagnostic",
                    parentNodeId = 100,
                    targetNodeId = 0,
                    aiProfileId = 2,
                    orderIndex = 4
                )
            )

            // Press 5 -> Help
            db.ivrNodeDao().insertNode(
                IvrNodeEntity(
                    id = 105,
                    flowId = flowId,
                    nodeType = "MESSAGE",
                    title = "Help Information",
                    messagePrompt = "Klash AI is your personal voice gateway. You can press keypad digits or speak commands naturally. To return to the main menu at any time, say 'Main Menu' or press star. Press 9 or say 'Goodbye' to hang up.",
                    dtmfKey = "5",
                    speechKeywords = "help, info, instructions",
                    parentNodeId = 100,
                    targetNodeId = 100,
                    orderIndex = 5
                )
            )

            // 4. Talking Commands
            db.talkingCommandDao().insertCommand(
                TalkingCommandEntity(
                    id = 1,
                    triggerPhrase = "Check my phone",
                    aliases = "Tell me about my phone,Check my device,What's my phone status,Give me my phone information,Device status",
                    matchingMode = "BOTH",
                    actionsJson = """[
                        {"actionType":"TOOL","name":"get_ram"},
                        {"actionType":"TOOL","name":"get_storage"},
                        {"actionType":"TOOL","name":"get_battery"},
                        {"actionType":"SPEAK_SUMMARY","prompt":"Summarize RAM, storage, and battery concisely in spoken format."}
                    ]""".trimIndent(),
                    confirmationPolicy = "NOT_REQUIRED",
                    isEnabled = true,
                    description = "Collects RAM, storage, and battery, then generates a spoken telemetry overview."
                )
            )

            db.talkingCommandDao().insertCommand(
                TalkingCommandEntity(
                    id = 2,
                    triggerPhrase = "Check my server",
                    aliases = "Minecraft server status,How is the server,Is Minecraft online,Server info",
                    matchingMode = "BOTH",
                    actionsJson = """[
                        {"actionType":"TOOL","name":"server_status"},
                        {"actionType":"TOOL","name":"player_count"},
                        {"actionType":"SPEAK_SUMMARY","prompt":"Report Minecraft server online status and active player count."}
                    ]""".trimIndent(),
                    confirmationPolicy = "NOT_REQUIRED",
                    isEnabled = true,
                    description = "Checks Pterodactyl Minecraft server status and online players."
                )
            )

            db.talkingCommandDao().insertCommand(
                TalkingCommandEntity(
                    id = 3,
                    triggerPhrase = "Goodbye",
                    aliases = "Bye,End call,Hang up,Quit,Disconnect",
                    matchingMode = "EXACT",
                    actionsJson = """[
                        {"actionType":"SPEAK","text":"Thank you for calling Klash AI. Goodbye."},
                        {"actionType":"END_CALL"}
                    ]""".trimIndent(),
                    confirmationPolicy = "NOT_REQUIRED",
                    isEnabled = true,
                    description = "Politely concludes the conversation and disconnects the call."
                )
            )

            // 5. Initial Memories
            db.memoryDao().insertMemory(
                MemoryEntity(
                    id = 1,
                    category = "SERVER",
                    memoryKey = "server_name",
                    memoryValue = "Survival Realm",
                    aiProfileId = 0
                )
            )
            db.memoryDao().insertMemory(
                MemoryEntity(
                    id = 2,
                    category = "PREFERENCE",
                    memoryKey = "owner_greeting",
                    memoryValue = "Call me Chief and prioritize battery alerts below 25 percent.",
                    aiProfileId = 0
                )
            )

            // 6. Caller Profiles
            db.callerProfileDao().insertCallerProfile(
                CallerProfileEntity(
                    id = 1,
                    phoneNumber = "+15550001234",
                    callerName = "Owner (Mobile)",
                    tier = "OWNER",
                    allowedAiProfiles = "*",
                    allowedCommands = "*",
                    allowedTools = "*",
                    maxCallDurationSeconds = 3600,
                    notes = "Primary device owner with full system access"
                )
            )
            db.callerProfileDao().insertCallerProfile(
                CallerProfileEntity(
                    id = 2,
                    phoneNumber = "*",
                    callerName = "General Guest",
                    tier = "GUEST",
                    allowedAiProfiles = "1",
                    allowedCommands = "Check my phone,Goodbye",
                    allowedTools = "get_ram,get_storage,get_battery,get_network",
                    maxCallDurationSeconds = 300,
                    notes = "Default permissions for unknown incoming numbers"
                )
            )

            // 7. Integrations
            db.integrationDao().insertIntegration(
                IntegrationEntity(
                    id = 1,
                    integrationType = "PTERODACTYL",
                    name = "Pterodactyl Panel",
                    endpointUrl = "https://panel.example.com",
                    isEnabled = false,
                    extraConfigJson = """{"serverId":"srv-12345","apiKeyConfigured":false}"""
                )
            )
            db.integrationDao().insertIntegration(
                IntegrationEntity(
                    id = 2,
                    integrationType = "DISCORD",
                    name = "Discord Webhook",
                    endpointUrl = "",
                    isEnabled = false,
                    extraConfigJson = """{"channelName":"alerts"}"""
                )
            )
            db.integrationDao().insertIntegration(
                IntegrationEntity(
                    id = 3,
                    integrationType = "WEB_SEARCH",
                    name = "Web Search Gateway",
                    endpointUrl = "https://api.duckduckgo.com",
                    isEnabled = true,
                    extraConfigJson = """{"searchEngine":"DuckDuckGo"}"""
                )
            )
        }
    }
}
