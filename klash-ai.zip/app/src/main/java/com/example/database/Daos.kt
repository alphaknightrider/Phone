package com.example.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CallLogDao {
    @Query("SELECT * FROM call_logs ORDER BY startTime DESC")
    fun getAllLogs(): Flow<List<CallLogEntity>>

    @Query("SELECT * FROM call_logs WHERE id = :id LIMIT 1")
    suspend fun getLogById(id: Long): CallLogEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: CallLogEntity): Long

    @Query("DELETE FROM call_logs WHERE id = :id")
    suspend fun deleteLog(id: Long)

    @Query("DELETE FROM call_logs")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM call_logs")
    fun getCallCount(): Flow<Int>
}

@Dao
interface AIProfileDao {
    @Query("SELECT * FROM ai_profiles ORDER BY id ASC")
    fun getAllProfiles(): Flow<List<AIProfileEntity>>

    @Query("SELECT * FROM ai_profiles WHERE id = :id LIMIT 1")
    suspend fun getProfileById(id: Long): AIProfileEntity?

    @Query("SELECT * FROM ai_profiles WHERE isDefault = 1 LIMIT 1")
    suspend fun getDefaultProfile(): AIProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: AIProfileEntity): Long

    @Update
    suspend fun updateProfile(profile: AIProfileEntity)

    @Query("DELETE FROM ai_profiles WHERE id = :id")
    suspend fun deleteProfile(id: Long)
}

@Dao
interface CallFlowDao {
    @Query("SELECT * FROM call_flows ORDER BY id ASC")
    fun getAllFlows(): Flow<List<CallFlowEntity>>

    @Query("SELECT * FROM call_flows WHERE id = :id LIMIT 1")
    suspend fun getFlowById(id: Long): CallFlowEntity?

    @Query("SELECT * FROM call_flows WHERE isDefault = 1 LIMIT 1")
    suspend fun getDefaultFlow(): CallFlowEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlow(flow: CallFlowEntity): Long

    @Update
    suspend fun updateFlow(flow: CallFlowEntity)

    @Query("DELETE FROM call_flows WHERE id = :id")
    suspend fun deleteFlow(id: Long)
}

@Dao
interface IvrNodeDao {
    @Query("SELECT * FROM ivr_nodes WHERE flowId = :flowId ORDER BY orderIndex ASC")
    fun getNodesForFlow(flowId: Long): Flow<List<IvrNodeEntity>>

    @Query("SELECT * FROM ivr_nodes WHERE flowId = :flowId")
    suspend fun getNodesListForFlow(flowId: Long): List<IvrNodeEntity>

    @Query("SELECT * FROM ivr_nodes WHERE id = :id LIMIT 1")
    suspend fun getNodeById(id: Long): IvrNodeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNode(node: IvrNodeEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNodes(nodes: List<IvrNodeEntity>)

    @Update
    suspend fun updateNode(node: IvrNodeEntity)

    @Query("DELETE FROM ivr_nodes WHERE id = :id")
    suspend fun deleteNode(id: Long)

    @Query("DELETE FROM ivr_nodes WHERE flowId = :flowId")
    suspend fun deleteNodesForFlow(flowId: Long)
}

@Dao
interface TalkingCommandDao {
    @Query("SELECT * FROM talking_commands ORDER BY id ASC")
    fun getAllCommands(): Flow<List<TalkingCommandEntity>>

    @Query("SELECT * FROM talking_commands WHERE isEnabled = 1")
    suspend fun getActiveCommands(): List<TalkingCommandEntity>

    @Query("SELECT * FROM talking_commands WHERE id = :id LIMIT 1")
    suspend fun getCommandById(id: Long): TalkingCommandEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommand(command: TalkingCommandEntity): Long

    @Update
    suspend fun updateCommand(command: TalkingCommandEntity)

    @Query("DELETE FROM talking_commands WHERE id = :id")
    suspend fun deleteCommand(id: Long)

    @Query("SELECT COUNT(*) FROM talking_commands WHERE isEnabled = 1")
    fun getActiveCommandCount(): Flow<Int>
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY timestamp DESC")
    fun getAllMemories(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE memoryKey LIKE '%' || :query || '%' OR memoryValue LIKE '%' || :query || '%'")
    suspend fun searchMemories(query: String): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE memoryKey = :key LIMIT 1")
    suspend fun getByKey(key: String): MemoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryEntity): Long

    @Update
    suspend fun updateMemory(memory: MemoryEntity)

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun deleteMemory(id: Long)

    @Query("DELETE FROM memories")
    suspend fun clearAll()
}

@Dao
interface ToolExecutionDao {
    @Query("SELECT * FROM tool_executions ORDER BY timestamp DESC LIMIT 100")
    fun getRecentExecutions(): Flow<List<ToolExecutionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExecution(execution: ToolExecutionEntity): Long

    @Query("DELETE FROM tool_executions")
    suspend fun clearHistory()
}

@Dao
interface CallerProfileDao {
    @Query("SELECT * FROM caller_profiles ORDER BY callerName ASC")
    fun getAllCallerProfiles(): Flow<List<CallerProfileEntity>>

    @Query("SELECT * FROM caller_profiles WHERE phoneNumber = :phoneNumber LIMIT 1")
    suspend fun getProfileForNumber(phoneNumber: String): CallerProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCallerProfile(profile: CallerProfileEntity): Long

    @Update
    suspend fun updateCallerProfile(profile: CallerProfileEntity)

    @Query("DELETE FROM caller_profiles WHERE id = :id")
    suspend fun deleteCallerProfile(id: Long)
}

@Dao
interface IntegrationDao {
    @Query("SELECT * FROM integrations ORDER BY id ASC")
    fun getAllIntegrations(): Flow<List<IntegrationEntity>>

    @Query("SELECT * FROM integrations WHERE integrationType = :type LIMIT 1")
    suspend fun getByType(type: String): IntegrationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIntegration(integration: IntegrationEntity): Long

    @Update
    suspend fun updateIntegration(integration: IntegrationEntity)
}

@Dao
interface ScheduledTaskDao {
    @Query("SELECT * FROM scheduled_tasks ORDER BY id ASC")
    fun getAllTasks(): Flow<List<ScheduledTaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: ScheduledTaskEntity): Long

    @Update
    suspend fun updateTask(task: ScheduledTaskEntity)

    @Query("DELETE FROM scheduled_tasks WHERE id = :id")
    suspend fun deleteTask(id: Long)
}
