package com.example.telecom

import android.app.role.RoleManager
import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Build
import android.telecom.*
import com.example.KlashApplication

/**
 * KlashInCallService provides legitimate call-control integration with Android's Telecom framework.
 *
 * NOTE ON AUDIO LIMITATIONS:
 * In Android's standard security model, an InCallService can control call state (answer, reject, mute, DTMF),
 * but ordinary non-system applications cannot arbitrarily inject raw synthesized speech or siphon raw cellular
 * audio streams on normal SIM carrier calls. For two-way AI conversational media, Klash AI utilizes ConnectionService
 * or VoIP/SIP media streams.
 */
class KlashInCallService : InCallService() {
    private val callCallback = object : Call.Callback() {
        override fun onStateChanged(call: Call?, state: Int) {
            super.onStateChanged(call, state)
            when (state) {
                Call.STATE_RINGING -> {
                    // Incoming SIM call detected
                }
                Call.STATE_ACTIVE -> {
                    // Call connected
                }
                Call.STATE_DISCONNECTED -> {
                    // Call disconnected
                }
            }
        }

        override fun onPostDialWait(call: Call?, remainingPostDialSequence: String?) {
            super.onPostDialWait(call, remainingPostDialSequence)
        }
    }

    override fun onCallAdded(call: Call?) {
        super.onCallAdded(call)
        call?.registerCallback(callCallback)
    }

    override fun onCallRemoved(call: Call?) {
        super.onCallRemoved(call)
        call?.unregisterCallback(callCallback)
    }
}

/**
 * KlashConnectionService handles full two-way AI Voice Media calls over VoIP, SIP, or Self-Managed Telephony.
 */
class KlashConnectionService : ConnectionService() {
    override fun onCreateIncomingConnection(
        connectionManagerPhoneAccount: PhoneAccountHandle?,
        request: ConnectionRequest?
    ): Connection {
        val connection = KlashAiConnection()
        connection.setInitializing()
        connection.connectionCapabilities = Connection.CAPABILITY_MUTE or Connection.CAPABILITY_SUPPORT_HOLD
        connection.audioModeIsVoip = true
        connection.setAddress(request?.address ?: Uri.parse("tel:+15550001234"), TelecomManager.PRESENTATION_ALLOWED)
        connection.setRinging()
        return connection
    }

    override fun onCreateOutgoingConnection(
        connectionManagerPhoneAccount: PhoneAccountHandle?,
        request: ConnectionRequest?
    ): Connection {
        val connection = KlashAiConnection()
        connection.setInitializing()
        connection.connectionCapabilities = Connection.CAPABILITY_MUTE or Connection.CAPABILITY_SUPPORT_HOLD
        connection.audioModeIsVoip = true
        connection.setAddress(request?.address, TelecomManager.PRESENTATION_ALLOWED)
        connection.setActive()
        return connection
    }

    class KlashAiConnection : Connection() {
        override fun onAnswer() {
            setActive()
        }

        override fun onReject() {
            setDisconnected(DisconnectCause(DisconnectCause.REJECTED))
            destroy()
        }

        override fun onDisconnect() {
            setDisconnected(DisconnectCause(DisconnectCause.LOCAL))
            destroy()
        }
    }
}

class PhoneAccountManager(private val context: Context) {
    private val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager

    fun getPhoneAccountHandle(): PhoneAccountHandle {
        val component = ComponentName(context, KlashConnectionService::class.java)
        return PhoneAccountHandle(component, "klash_ai_account")
    }

    fun registerPhoneAccount(displayName: String = "Klash AI Phone Agent") {
        try {
            val handle = getPhoneAccountHandle()
            val phoneAccount = PhoneAccount.builder(handle, displayName)
                .setCapabilities(PhoneAccount.CAPABILITY_SELF_MANAGED or PhoneAccount.CAPABILITY_CALL_PROVIDER)
                .setIcon(android.graphics.drawable.Icon.createWithResource(context, com.example.R.mipmap.ic_launcher))
                .setShortDescription("Programmable AI Voice Phone Agent")
                .build()
            telecomManager.registerPhoneAccount(phoneAccount)
        } catch (_: Exception) {}
    }

    fun isDefaultDialer(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(Context.ROLE_SERVICE) as? RoleManager
            roleManager?.isRoleHeld(RoleManager.ROLE_DIALER) == true
        } else {
            telecomManager.defaultDialerPackage == context.packageName
        }
    }
}
